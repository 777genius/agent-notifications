// node_modules/universal-agent-plugins-opencode-events/observer-core.js
var id = (x) => typeof x === "string" && x.length > 0 && !/[\u0000-\u001f]/u.test(x) && new TextEncoder().encode(x).length <= 256;
var timestamp = (x) => Number.isSafeInteger(x) && x > 0;
var canonicalID = (generation, session, turn, kind, nativeID) => JSON.stringify([generation, session, turn, kind, nativeID]);
function createCore(options) {
  const now = options.clock ? () => options.clock.now() : () => performance.now();
  const clockID = options.clock?.id ?? "local-performance";
  if (!id(clockID) || !Number.isFinite(now())) throw new TypeError("valid monotonic clock required");
  const diag = (reason) => {
    try {
      options.onDiagnostic?.(reason);
    } catch {
    }
  };
  const jobs = /* @__PURE__ */ new Set(), lookups = /* @__PURE__ */ new Set(), tails = /* @__PURE__ */ new Map(), emitWaiters = /* @__PURE__ */ new Set();
  let generation = 0, emitting = 0;
  const limit = (x, max) => Number.isInteger(x) ? Math.max(1, Math.min(max, x)) : max;
  const jobLimit = limit(options.maxJobs, 256), lookupLimit = limit(options.maxConcurrentLookups, 16);
  const timeout = limit(options.lookupTimeoutMs, 2e3);
  function invalidate() {
    generation++;
    for (const job of jobs) job.controller.abort();
    for (const controller of lookups) controller.abort();
    for (const wake of emitWaiters) wake();
  }
  function submit(sid, relevant, work, born = now()) {
    if (jobs.size >= jobLimit) {
      diag("job_capacity");
      return;
    }
    const controller = new AbortController(), connection = generation;
    const valid2 = () => !controller.signal.aborted && connection === generation && now() - born <= 3e4 && relevant();
    const job = { controller, valid: valid2 };
    jobs.add(job);
    const timer = setTimeout(() => {
      diag("job_expired");
      controller.abort();
    }, Math.max(0, 3e4 - (now() - born)));
    const before = tails.get(sid) ?? Promise.resolve();
    const after = before.then(async () => {
      if (valid2()) await work({ signal: controller.signal, isCurrent: valid2, metadataDeadline: now() + timeout, ingressMonotonicMs: born, clockID });
    }).catch(() => diag("job_failed")).finally(() => {
      clearTimeout(timer);
      jobs.delete(job);
      if (tails.get(sid) === after) tails.delete(sid);
    });
    tails.set(sid, after);
    return after;
  }
  async function lookup(call, handoff) {
    if (!handoff.isCurrent()) return;
    if (lookups.size >= lookupLimit) {
      diag("lookup_capacity");
      return;
    }
    const remaining = Math.min(timeout, (handoff.metadataDeadline ?? now() + timeout) - now());
    if (remaining <= 0) {
      diag("lookup_timeout");
      return;
    }
    const deadline = now() + remaining;
    const controller = new AbortController();
    lookups.add(controller);
    const abort = () => controller.abort();
    handoff.signal.addEventListener("abort", abort, { once: true });
    let timer, cancel;
    const request = Promise.resolve().then(() => {
      if (controller.signal.aborted) return;
      if (now() > deadline) {
        diag("lookup_timeout");
        controller.abort();
        return;
      }
      return call(controller.signal);
    });
    request.then(() => lookups.delete(controller), () => lookups.delete(controller));
    try {
      const result = await Promise.race([request, new Promise((resolve2) => {
        cancel = () => resolve2(void 0);
        controller.signal.addEventListener("abort", cancel, { once: true });
        timer = setTimeout(() => {
          diag("lookup_timeout");
          controller.abort();
        }, remaining);
        if (controller.signal.aborted) cancel();
      })]);
      if (now() > deadline && !controller.signal.aborted) {
        diag("lookup_timeout");
        controller.abort();
      }
      return handoff.isCurrent() && !controller.signal.aborted ? result : void 0;
    } catch {
      diag("lookup_failed");
    } finally {
      clearTimeout(timer);
      controller.signal.removeEventListener("abort", cancel);
      handoff.signal.removeEventListener("abort", abort);
    }
  }
  async function emit(fact, handoff) {
    const deadline = handoff.metadataDeadline ?? now() + timeout;
    const current = () => handoff.isCurrent() && now() < deadline;
    while (emitting >= 4 && current()) {
      await new Promise((resolve2) => {
        let timer;
        const wake = () => {
          clearTimeout(timer);
          emitWaiters.delete(wake);
          handoff.signal.removeEventListener("abort", wake);
          resolve2();
        };
        emitWaiters.add(wake);
        handoff.signal.addEventListener("abort", wake, { once: true });
        timer = setTimeout(wake, Math.max(0, deadline - now()));
        if (handoff.signal.aborted) wake();
      });
    }
    if (!current()) return false;
    if (fact.provenance) Object.freeze(fact.provenance);
    Object.freeze(fact);
    if (new TextEncoder().encode(JSON.stringify(fact)).length > 4096) {
      diag("frame_capacity");
      return false;
    }
    emitting++;
    let preparation, preparationController;
    const abortPreparation = () => preparationController?.abort();
    handoff.signal.addEventListener("abort", abortPreparation, { once: true });
    try {
      if (options.beforeEmit) {
        const ready = await lookup((signal) => {
          preparationController = new AbortController();
          const abort = () => preparationController.abort();
          signal.addEventListener("abort", abort, { once: true });
          if (signal.aborted || handoff.signal.aborted) abort();
          const projected = Object.freeze({
            signal: preparationController.signal,
            ingressMonotonicMs: handoff.ingressMonotonicMs,
            clockID: handoff.clockID,
            metadataDeadline: deadline,
            isCurrent: () => current() && !preparationController.signal.aborted
          });
          preparation = Promise.resolve(projected.isCurrent() ? options.beforeEmit(fact, projected) : false);
          preparation.then(
            () => signal.removeEventListener("abort", abort),
            () => signal.removeEventListener("abort", abort)
          );
          return preparation;
        }, { ...handoff, metadataDeadline: deadline });
        if (ready !== true || !current()) return false;
      }
      if (handoff.revalidate && !await handoff.revalidate()) return false;
      if (!current()) return false;
      await options.emit(fact, handoff);
      return true;
    } catch {
      diag("observed event callback failed");
      return false;
    } finally {
      abortPreparation();
      try {
        await preparation;
      } catch {
      }
      handoff.signal.removeEventListener("abort", abortPreparation);
      emitting--;
      for (const wake of emitWaiters) wake();
    }
  }
  return {
    now,
    clockID,
    diag,
    submit,
    lookup,
    emit,
    invalidate,
    recheck() {
      for (const job of jobs) if (!job.valid()) job.controller.abort();
    },
    drain: () => Promise.all([...tails.values()]),
    busy: () => jobs.size > 0
  };
}

// node_modules/universal-agent-plugins-opencode-events/v1.js
var object = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
var id2 = (x) => typeof x === "string" && x.length > 0 && !/[\u0000-\u001f]/u.test(x) && new TextEncoder().encode(x).length <= 256;
var typeOK = (x) => typeof x === "string" && /^[a-z][a-z0-9.-]{0,79}$/.test(x);
var nativeSessionID = (event) => ["session.updated", "session.deleted"].includes(event?.type) ? event?.properties?.info?.id ?? event?.properties?.sessionID : event?.properties?.sessionID ?? event?.properties?.info?.sessionID;
function createObserver(options) {
  if (typeof options?.emit !== "function" || typeof options.client?.session?.messages !== "function" || typeof options.client?.session?.get !== "function") {
    throw new TypeError("emit, messages and get required");
  }
  const limit = Math.max(2, Math.min(100, Number.isInteger(options.messageLimit) ? options.messageLimit : 30));
  const maxSessions = Math.max(1, Math.min(512, Number.isInteger(options.dedupLimit) ? options.dedupLimit : 512));
  const timeoutMs = Math.max(100, Math.min(2e3, Number.isInteger(options.lookupTimeoutMs) ? options.lookupTimeoutMs : 2e3));
  const sessions = /* @__PURE__ */ new Map(), unknownSeen = /* @__PURE__ */ new Set();
  let activeJobs = 0, disposed = false;
  const lifetime = new AbortController(), handoffs = /* @__PURE__ */ new Set(), core = createCore({
    ...options,
    lookupTimeoutMs: timeoutMs,
    onDiagnostic: (reason) => options.onDiagnostic?.(reason === "lookup_capacity" ? "messages lookup capacity exceeded" : ["lookup_timeout", "lookup_failed"].includes(reason) ? "lookup failed or timed out" : reason)
  }), jobsBySession = /* @__PURE__ */ new Map();
  const now = core.now;
  const strict = typeof options.runtimeEligibility === "function";
  let runtime = "supported";
  if (strict) {
    try {
      runtime = options.runtimeEligibility();
    } catch {
      runtime = "unverified";
    }
  }
  const diag = (reason) => {
    try {
      options.onDiagnostic?.(reason);
    } catch {
    }
  };
  const state = (sid) => {
    if (!sessions.has(sid)) {
      const fresh = {
        user: "",
        userCreated: void 0,
        seenUsers: /* @__PURE__ */ new Set(),
        assistant: "",
        failedAssistant: "",
        overflowPending: false,
        idleObserved: false,
        retry: false,
        retryAssistant: "",
        cancelled: false,
        questions: /* @__PURE__ */ new Set(),
        permissions: /* @__PURE__ */ new Set(),
        requestBindings: /* @__PURE__ */ new Map(),
        resolved: /* @__PURE__ */ new Set(),
        admitted: /* @__PURE__ */ new Set(),
        turnEpoch: 0,
        revision: 0,
        errorPending: 0,
        rootSession: void 0,
        activeAssistant: "",
        activeCompleted: false,
        ambiguousAssistant: false,
        sourceError: void 0,
        compaction: false,
        activeCreated: void 0,
        compactionFloor: void 0
      };
      if (strict && sessions.size >= maxSessions) {
        for (const [key2, value] of sessions) {
          if (!jobsBySession.has(key2) && (value.cancelled || value.admitted.has("idle") || value.admitted.has("error"))) {
            sessions.delete(key2);
            break;
          }
        }
        if (sessions.size >= maxSessions) {
          diag("session_capacity");
          return { ...fresh, cancelled: true };
        }
      }
      sessions.set(sid, fresh);
      if (sessions.size > maxSessions) sessions.delete(sessions.keys().next().value);
    }
    return sessions.get(sid);
  };
  async function emit(fact, key2, session, nativeTime, timeBasis, revalidate, born = now(), nativeMessageID) {
    if (disposed) return;
    if (strict && (!timestamp(nativeTime) || fact.rootSession !== true || !session?.scopeMatched)) {
      core.diag("native_provenance_unverified");
      return;
    }
    const controller = new AbortController();
    const epoch = session?.turnEpoch, revision = session?.revision;
    const requestSet = fact.kind === "question_asked" ? session?.questions : session?.permissions;
    const relevant = () => !disposed && !controller.signal.aborted && now() - born <= 3e4 && (!session || sessions.get(fact.sessionID) === session && session.turnEpoch === epoch && (fact.requestID ? requestSet.has(fact.requestID) && !session.cancelled && !session.compaction && !session.ambiguousAssistant && !session.sourceError : session.revision === revision));
    if (!relevant()) return;
    if (strict && timestamp(nativeTime)) fact.provenance = {
      generation: "v1",
      observationID: canonicalID("v1", fact.sessionID, fact.turnID, fact.kind, fact.requestID ?? fact.messageID ?? nativeMessageID),
      nativeTime,
      timeBasis,
      ...nativeMessageID ? { nativeMessageID } : {}
    };
    const handoff = { signal: controller.signal, isCurrent: relevant, revalidate, ingressMonotonicMs: born, clockID: core.clockID, metadataDeadline: born + timeoutMs };
    const timer = setTimeout(() => controller.abort(), Math.max(0, 3e4 - (now() - born)));
    const owned = { controller, relevant };
    handoffs.add(owned);
    const admitted = session ? session.admitted : unknownSeen;
    if (admitted.has(key2)) {
      clearTimeout(timer);
      handoffs.delete(owned);
      return;
    }
    admitted.add(key2);
    if (!session && admitted.size > maxSessions) admitted.delete(admitted.values().next().value);
    try {
      await core.emit({ version: 1, ...fact }, handoff);
    } catch {
      diag("observed event callback failed");
    } finally {
      clearTimeout(timer);
      handoffs.delete(owned);
    }
  }
  async function boundedLookup(call, deadline = now() + timeoutMs) {
    return core.lookup(call, {
      signal: lifetime.signal,
      isCurrent: () => !disposed,
      metadataDeadline: deadline
    });
  }
  async function rootStatus(sid, deadline) {
    const s = state(sid);
    if (!strict && typeof s.rootSession === "boolean") return s.rootSession;
    const result = await boundedLookup((signal) => options.client.session.get({ path: { id: sid }, signal }), deadline);
    const info = result?.data ?? result;
    if (!object(info) || info.id !== sid || info.parentID !== void 0 && !id2(info.parentID)) {
      diag("invalid session ancestry");
      return;
    }
    s.rootSession = info.parentID === void 0;
    s.scopeMatched = typeof options.location === "string" && info.directory === options.location;
    return s.rootSession;
  }
  async function latest(sid, deadline) {
    const result = await boundedLookup((signal) => options.client.session.messages({
      path: { id: sid },
      query: { limit },
      signal
    }), deadline);
    const rows2 = Array.isArray(result) ? result : result?.data;
    if (!Array.isArray(rows2) || rows2.length > limit) {
      diag("invalid messages lookup");
      return;
    }
    const messages = rows2.map((x) => x?.info ?? x);
    if (!messages.every((m) => object(m) && id2(m.id) && m.sessionID === sid && ["user", "assistant"].includes(m.role))) {
      diag("invalid or mismatched messages");
      return;
    }
    return messages;
  }
  function currentTurn(messages, uid) {
    const lastUser = messages.findLast((m) => m.role === "user");
    if (lastUser) return lastUser.id === uid;
    return messages.at(-1)?.role === "assistant" && messages.at(-1).parentID === uid;
  }
  async function idle(sid, born, deadline) {
    const s = state(sid), revision = s.revision, uid = s.user;
    s.idleObserved = true;
    const failed = Boolean(s.failedAssistant || s.overflowPending);
    if (activeJobs > 256 || !uid || s.compaction || s.ambiguousAssistant || !s.assistant && !failed || s.admitted.has("idle") || s.admitted.has("error") || s.retry && !failed || s.cancelled || s.errorPending || s.questions.size || s.permissions.size) return;
    const messages = await latest(sid, deadline);
    if (!messages || sessions.get(sid) !== s || revision !== s.revision || s.user !== uid || s.retry && !failed || s.cancelled || s.errorPending || s.questions.size || s.permissions.size) return;
    if (!currentTurn(messages, uid)) return;
    const answer = messages.at(-1);
    if (strict && answer?.path?.cwd !== options.location) {
      diag("scope_unverified");
      return;
    }
    if (s.failedAssistant || s.overflowPending) {
      if (strict && !s.sourceError) return;
      if (!answer || answer.role !== "assistant" || answer.parentID !== uid || s.failedAssistant && answer.id !== s.failedAssistant || strict && !timestamp(answer.time?.completed) || !object(answer.error) || s.sourceError && (answer.id !== s.sourceError.messageID || answer.error.name !== s.sourceError.name) || s.compaction || /abort|cancel/i.test(String(answer.error.name ?? ""))) return;
      if (s.overflowPending && !s.failedAssistant && answer.error.name !== "ContextOverflowError") return;
      const rootSession2 = await rootStatus(sid, deadline);
      if (rootSession2 === void 0 || sessions.get(sid) !== s || revision !== s.revision || s.user !== uid || s.cancelled) return;
      s.cancelled = true;
      s.revision++;
      await emit({ kind: "terminal_error", sessionID: sid, turnID: uid, rootSession: rootSession2 }, "error", s, answer.time?.created, "assistant_created_lower_bound", void 0, born, answer.id);
      return;
    }
    if (!answer || answer.role !== "assistant" || answer.id !== s.assistant || answer.parentID !== uid || answer.finish !== "stop" || !Number.isFinite(answer.time?.completed) || answer.error != null) return;
    const rootSession = await rootStatus(sid, deadline);
    if (rootSession === void 0 || sessions.get(sid) !== s || revision !== s.revision || s.user !== uid || s.cancelled || s.errorPending) return;
    await emit({ kind: "turn_idle_verified", sessionID: sid, turnID: uid, messageID: answer.id, rootSession }, "idle", s, answer.time?.completed, "assistant_completed", void 0, born);
  }
  async function observe(event, born, deadline) {
    if (!object(event) || !typeOK(event.type) || !object(event.properties)) {
      diag("invalid native event");
      return;
    }
    const { type, properties: p } = event;
    if (type === "message.updated") {
      const m = p.info;
      if (!object(m) || !id2(m.id) || !id2(m.sessionID) || !["user", "assistant"].includes(m.role)) {
        diag("invalid message.updated");
        return;
      }
      const s = state(m.sessionID);
      if (m.role === "user" && m.id !== s.user) {
        const created = m.time?.created;
        if (s.seenUsers.has(m.id) || Number.isFinite(created) && Number.isFinite(s.userCreated) && created < s.userCreated) return;
        s.seenUsers.add(m.id);
        if (s.seenUsers.size > 512) s.seenUsers.delete(s.seenUsers.values().next().value);
        s.userCreated = Number.isFinite(created) ? created : void 0;
        s.user = m.id;
        s.assistant = "";
        s.retry = false;
        s.retryAssistant = "";
        s.cancelled = false;
        s.failedAssistant = "";
        s.overflowPending = false;
        s.idleObserved = false;
        s.questions.clear();
        s.permissions.clear();
        s.requestBindings.clear();
        s.resolved.clear();
        s.admitted.clear();
        s.activeAssistant = "";
        s.activeCreated = void 0;
        s.activeCompleted = false;
        s.ambiguousAssistant = false;
        s.sourceError = void 0;
        s.compaction = false;
        s.turnEpoch++;
        s.revision++;
      }
      if (m.role === "assistant" && m.parentID === s.user && m.summary !== true) {
        if (strict && s.activeAssistant && s.activeAssistant !== m.id) {
          for (const requestID of [...s.questions, ...s.permissions]) s.resolved.add(requestID);
          s.questions.clear();
          s.permissions.clear();
          s.revision++;
        }
        if (strict && s.activeAssistant && s.activeAssistant !== m.id && !s.activeCompleted) s.ambiguousAssistant = true;
        if (s.compaction && timestamp(m.time?.created) && timestamp(s.compactionFloor) && m.time.created > s.compactionFloor && m.id !== s.activeAssistant) {
          s.compaction = false;
          s.sourceError = void 0;
          s.ambiguousAssistant = false;
        }
        s.activeAssistant = m.id;
        s.activeCreated = m.time?.created;
        s.activeCompleted = Number.isFinite(m.time?.completed);
      }
      if (strict && m.role === "assistant" && m.summary === true && m.parentID === s.user) {
        s.compactionFloor = m.time?.created;
        s.compaction = true;
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
      }
      if (m.role === "assistant" && (!strict || m.summary !== true) && m.parentID === s.user && m.finish === "stop" && Number.isFinite(m.time?.completed) && m.error == null && m.id !== s.retryAssistant) {
        s.assistant = m.id;
        s.failedAssistant = "";
        s.overflowPending = false;
        s.retry = false;
        s.revision++;
      }
      if (m.role === "assistant" && (!strict || m.summary !== true) && m.parentID === s.user && m.error != null) {
        s.assistant = "";
        s.failedAssistant = m.id;
        s.revision++;
        s.questions.clear();
        s.permissions.clear();
        if (strict && s.idleObserved && !s.errorPending) await idle(m.sessionID, born, deadline);
      }
      return;
    }
    if (type === "session.status") {
      if (!id2(p.sessionID) || !object(p.status) || !["busy", "idle", "retry"].includes(p.status.type)) {
        diag("invalid session.status");
        return;
      }
      if (p.status.type === "busy") {
        const s = state(p.sessionID);
        s.idleObserved = false;
        s.revision++;
      }
      if (p.status.type === "retry") {
        const s = state(p.sessionID);
        s.retryAssistant = s.assistant;
        s.assistant = "";
        s.failedAssistant = "";
        s.overflowPending = false;
        s.sourceError = void 0;
        s.idleObserved = false;
        s.retry = true;
        for (const requestID of [...s.questions, ...s.permissions]) s.resolved.add(requestID);
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
      }
      if (p.status.type === "idle") await idle(p.sessionID, born, deadline);
      return;
    }
    if (type === "session.idle") {
      if (!id2(p.sessionID)) {
        diag("invalid session.idle");
        return;
      }
      await idle(p.sessionID, born, deadline);
      return;
    }
    if (type === "question.asked" || type === "permission.asked") {
      const requestMessageID = p.messageID ?? p.tool?.messageID;
      if (!id2(p.sessionID) || !id2(p.id) || requestMessageID !== void 0 && !id2(requestMessageID)) {
        diag("invalid request");
        return;
      }
      if (type === "question.asked" && (!Array.isArray(p.questions) || p.questions.length === 0)) {
        diag("invalid question shape");
        return;
      }
      if (type === "permission.asked" && (typeof p.permission !== "string" || !p.permission)) {
        diag("invalid permission shape");
        return;
      }
      const s = state(p.sessionID), uid = s.user, epoch = s.turnEpoch;
      if (!uid || strict && (s.cancelled || s.compaction || s.sourceError || s.admitted.has("idle") || s.admitted.has("error")) || s.resolved.has(p.id)) {
        diag("unmatched or resolved request");
        return;
      }
      const pending = type === "question.asked" ? s.questions : s.permissions;
      if (s.questions.size + s.permissions.size + s.resolved.size >= 256 || strict && s.requestBindings.size >= 256) {
        s.cancelled = true;
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
        diag("request_capacity");
        return;
      }
      const assistantAtIngress = s.activeAssistant, createdAtIngress = s.activeCreated;
      if (strict) {
        const binding = JSON.stringify([type, requestMessageID, p.tool?.callID, createdAtIngress]);
        if (s.requestBindings.has(p.id)) {
          if (s.requestBindings.get(p.id) !== binding) {
            s.cancelled = true;
            s.questions.clear();
            s.permissions.clear();
            s.revision++;
            diag("request_identity_ambiguous");
          }
          return;
        }
        s.requestBindings.set(p.id, binding);
      }
      pending.add(p.id);
      s.revision++;
      const messages = await latest(p.sessionID, deadline);
      if (sessions.get(p.sessionID) !== s || s.turnEpoch !== epoch || s.user !== uid || !pending.has(p.id) || s.resolved.has(p.id)) return;
      if (!messages || !currentTurn(messages, uid)) {
        pending.delete(p.id);
        diag("unmatched request turn");
        return;
      }
      if (requestMessageID && requestMessageID !== uid && !messages.some((m) => m.role === "assistant" && m.id === requestMessageID && m.parentID === uid)) {
        pending.delete(p.id);
        diag("unmatched request message");
        return;
      }
      const rootSession = await rootStatus(p.sessionID, deadline);
      if (rootSession === void 0 || sessions.get(p.sessionID) !== s || s.turnEpoch !== epoch || s.user !== uid || !pending.has(p.id) || s.resolved.has(p.id)) return;
      const nativeAssistant = messages.find((m) => m.role === "assistant" && m.id === requestMessageID && m.parentID === uid);
      if (strict && (nativeAssistant?.path?.cwd !== options.location || nativeAssistant.summary === true || s.ambiguousAssistant || messages.findLast((m) => m.role === "assistant" && m.summary !== true)?.id !== requestMessageID)) {
        diag("scope_unverified");
        return;
      }
      const authority = options.callbackAuthority === "qualified_native_sync";
      const nativeBound = authority && requestMessageID === assistantAtIngress && assistantAtIngress === s.activeAssistant && id2(p.tool?.callID) && timestamp(createdAtIngress) && nativeAssistant?.time?.created === createdAtIngress && nativeAssistant?.summary !== true && !s.compaction && !s.sourceError && !s.ambiguousAssistant;
      if (strict && !nativeBound) {
        diag("callback_attention_authority_unverified");
        return;
      }
      s.assistant = "";
      s.revision++;
      await emit(
        {
          kind: type === "question.asked" ? "question_asked" : "permission_asked",
          sessionID: p.sessionID,
          turnID: uid,
          requestID: p.id,
          rootSession
        },
        `${type}:${p.id}`,
        s,
        strict && nativeBound ? createdAtIngress : void 0,
        "assistant_created_lower_bound",
        void 0,
        born
      );
      return;
    }
    if (type === "question.replied" || type === "question.rejected" || type === "permission.replied") {
      if (!id2(p.sessionID) || !id2(p.requestID)) {
        diag("invalid resolution");
        return;
      }
      const s = state(p.sessionID);
      const pending = type.startsWith("question.") ? s.questions : s.permissions;
      const current = pending.delete(p.requestID);
      s.resolved.add(p.requestID);
      if (s.resolved.size > 256) {
        s.cancelled = true;
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
        diag("request_capacity");
      }
      if (current) {
        s.assistant = "";
        s.revision++;
      }
      return;
    }
    if (strict && ["session.updated", "session.deleted"].includes(type) && id2(nativeSessionID(event))) {
      const sid = nativeSessionID(event), s = state(sid), info = p.info;
      if (type === "session.updated" && object(info) && info.id === sid && (p.sessionID === void 0 || p.sessionID === sid) && info.parentID === void 0 && typeof options.location === "string" && info.directory === options.location && object(info.time) && Number.isSafeInteger(info.time.created) && info.time.created >= 0 && Number.isSafeInteger(info.time.updated) && info.time.updated >= 0 && info.time.archived === void 0 && info.time.compacting === void 0 && info.revert === void 0) return;
      s.rootSession = void 0;
      s.scopeMatched = false;
      s.cancelled = true;
      s.questions.clear();
      s.permissions.clear();
      s.revision++;
      return;
    }
    if (strict && type === "session.compacted") {
      if (id2(p.sessionID)) {
        const s = state(p.sessionID);
        s.compaction = true;
        s.sourceError = void 0;
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
      }
      return;
    }
    if (type === "session.error") {
      if (!id2(p.sessionID) || !object(p.error) || p.messageID !== void 0 && !id2(p.messageID)) {
        diag("invalid session.error");
        return;
      }
      const s = state(p.sessionID), uid = s.user, epoch = s.turnEpoch;
      if (!uid || s.admitted.has("idle")) return;
      if (!strict) {
        s.errorPending++;
        s.revision++;
        const messages2 = await latest(p.sessionID, deadline);
        s.errorPending--;
        if (!messages2 || sessions.get(p.sessionID) !== s || s.turnEpoch !== epoch || s.user !== uid || s.admitted.has("idle") || !currentTurn(messages2, uid)) return;
        if (p.messageID && !messages2.some((m) => m.role === "assistant" && m.id === p.messageID && m.parentID === uid)) {
          diag("unmatched error message");
          return;
        }
        const rootSession = await rootStatus(p.sessionID, deadline);
        if (rootSession === void 0 || sessions.get(p.sessionID) !== s || s.turnEpoch !== epoch || s.user !== uid || s.admitted.has("idle")) return;
        if (p.error.name === "ContextOverflowError") {
          s.overflowPending = true;
          s.revision++;
          if (s.idleObserved) await idle(p.sessionID, born, deadline);
          return;
        }
        s.cancelled = true;
        s.revision++;
        if (/abort|cancel/i.test(String(p.error.name ?? ""))) return;
        await emit({ kind: "terminal_error", sessionID: p.sessionID, turnID: uid, rootSession }, "error", s, void 0, void 0, void 0, born);
        return;
      }
      s.questions.clear();
      s.permissions.clear();
      s.revision++;
      if (p.messageID && p.messageID !== s.activeAssistant) {
        diag("unmatched error message");
        return;
      }
      if (/abort|cancel/i.test(String(p.error.name ?? ""))) {
        s.cancelled = true;
        s.questions.clear();
        s.permissions.clear();
        s.revision++;
        return;
      }
      const candidate = s.activeAssistant;
      if (!candidate || s.compaction || s.ambiguousAssistant) {
        diag("unmatched error message");
        return;
      }
      s.sourceError = { messageID: candidate, name: p.error.name };
      s.questions.clear();
      s.permissions.clear();
      s.errorPending++;
      s.revision++;
      const messages = await latest(p.sessionID, deadline);
      s.errorPending--;
      if (!messages || sessions.get(p.sessionID) !== s || s.turnEpoch !== epoch || s.user !== uid || s.admitted.has("idle") || !currentTurn(messages, uid)) return;
      if (p.error.name === "ContextOverflowError") s.overflowPending = true;
      if (s.idleObserved) await idle(p.sessionID, born, deadline);
      return;
    }
    await emit(
      { kind: "unknown", nativeType: type, ...id2(p.sessionID) ? { sessionID: p.sessionID } : {} },
      `unknown:${type}:${id2(p.sessionID) ? p.sessionID : ""}`,
      void 0,
      void 0,
      void 0,
      void 0,
      born
    );
  }
  return {
    observe(event) {
      if (disposed) return Promise.resolve();
      if (strict && runtime !== "supported") {
        diag(runtime === "unsupported" ? "runtime_unsupported" : "runtime_unverified");
        return Promise.resolve();
      }
      const relevant = ["session.idle", "session.error", "question.asked", "permission.asked"].includes(event?.type) || event?.type === "session.status" && event.properties?.status?.type === "idle" || event?.type === "message.updated" && event.properties?.info?.error != null;
      const control = ["message.updated", "question.replied", "question.rejected", "permission.replied", "session.compacted"].includes(event?.type) || strict && ["session.updated", "session.deleted"].includes(event?.type) || event?.type === "session.status" && event.properties?.status?.type !== "idle";
      const sid = nativeSessionID(event);
      if ((relevant || !control) && activeJobs >= 256) {
        if (id2(sid)) {
          const s = state(sid);
          s.cancelled = true;
          s.questions.clear();
          s.permissions.clear();
          s.revision++;
        }
        for (const owned of handoffs) if (!owned.relevant()) owned.controller.abort();
        diag("job_capacity");
        return Promise.resolve();
      }
      const counted = relevant || !control;
      if (counted) {
        activeJobs++;
        if (id2(sid)) jobsBySession.set(sid, (jobsBySession.get(sid) ?? 0) + 1);
      }
      const born = now();
      const work = observe(event, born, born + timeoutMs);
      for (const owned of handoffs) if (!owned.relevant()) owned.controller.abort();
      return work.finally(() => {
        if (counted) {
          activeJobs--;
          const remaining = (jobsBySession.get(sid) ?? 1) - 1;
          if (remaining) jobsBySession.set(sid, remaining);
          else jobsBySession.delete(sid);
        }
      });
    },
    dispose() {
      disposed = true;
      sessions.clear();
      lifetime.abort();
      core.invalidate();
      for (const owned of handoffs) owned.controller.abort();
    }
  };
}

// node_modules/universal-agent-plugins-opencode-events/v2-reducer.js
var object2 = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
var id3 = (x) => typeof x === "string" && x.length > 0 && !/[\u0000-\u001f]/u.test(x) && new TextEncoder().encode(x).length <= 256;
var location = (x) => object2(x) && typeof x.directory === "string" && x.directory.length > 0 && (x.workspaceID === void 0 || id3(x.workspaceID));
var sameLocation = (a, b) => location(a) && location(b) && a.directory === b.directory && a.workspaceID === b.workspaceID;
var bounded = (value, fallback, min, max) => Math.max(min, Math.min(max, Number.isInteger(value) ? value : fallback));
var retainedAdd = (set, value, limit) => {
  set.add(value);
  if (set.size > limit) set.delete(set.values().next().value);
};
var supported = /* @__PURE__ */ new Set([
  "session.created",
  "session.moved",
  "session.deleted",
  "session.inbox.enqueued",
  "session.inbox.delivered",
  "session.inbox.cancelled",
  "session.inbox.delivery.changed",
  "session.execution.started",
  "session.execution.succeeded",
  "session.execution.failed",
  "session.execution.interrupted",
  "session.step.started",
  "session.step.ended",
  "session.step.failed",
  "session.retry.scheduled",
  "session.compaction.started",
  "session.compaction.ended",
  "session.compaction.failed",
  "form.created",
  "form.replied",
  "form.cancelled",
  "permission.asked",
  "permission.replied"
]);
function createV2Reducer(options, strict = false, fence = () => {
}) {
  if (!strict && (typeof options?.emit !== "function" || typeof options.client?.get !== "function" || typeof options.client?.context !== "function" || !location(options.location))) {
    throw new TypeError("emit, native get/context and location required");
  }
  const own2 = strict ? options.location : { directory: options.location.directory, workspaceID: options.location.workspaceID };
  const maxSessions = bounded(options.maxSessions, 512, 1, 512);
  const timeout = bounded(options.lookupTimeoutMs, 2e3, 100, 1e4);
  const sessions = /* @__PURE__ */ new Map(), eventIDs = /* @__PURE__ */ new Map();
  const core = createCore({ ...options, onDiagnostic(code) {
    diag(code);
    if (strict && ["job_capacity", "lookup_capacity", "lookup_timeout"].includes(code)) fence(code);
  } });
  let checkpoint;
  const now = core.now;
  const diagnosticCodes = /* @__PURE__ */ new Set();
  let disposed = false, lifecycle = 0;
  const diag = (code) => {
    if (diagnosticCodes.has(code)) return;
    diagnosticCodes.add(code);
    try {
      options.onDiagnostic?.(code);
    } catch {
    }
  };
  function invalidate(s) {
    s.generation++;
    s.revision++;
    sessions.delete(s.sid);
    core.recheck();
  }
  const activeOwned = (s) => ["root", "pending", "new"].includes(s.ownership) && (s.admissions.size > 0 || s.started && !s.result && !s.interrupted && (!s.terminal || s.verifying.size > 0));
  function state(sid) {
    if (sessions.has(sid)) {
      const existing = sessions.get(sid);
      sessions.delete(sid);
      sessions.set(sid, existing);
      return existing;
    }
    if (sessions.size === maxSessions) {
      if (strict) {
        const ended = [...sessions.values()].find((s2) => s2.result || s2.interrupted || s2.blocked);
        if (ended && !core.busy()) invalidate(ended);
        else {
          fence("session_capacity");
          return;
        }
      }
      const records = strict ? [] : [...sessions.values()];
      const victim = records.find((s2) => s2.ownership === "rejected" || s2.ownership === "child") ?? records.find((s2) => !activeOwned(s2) && !s2.verifying.size) ?? records[0];
      if (victim && activeOwned(victim)) diag("session_capacity");
      if (victim) invalidate(victim);
    }
    const s = {
      sid,
      generation: 0,
      ownership: "new",
      epoch: 0,
      revision: 0,
      started: false,
      user: "",
      assistant: "",
      final: "",
      retry: false,
      interrupted: false,
      compacting: false,
      compactedUser: "",
      blocked: false,
      admissionsOverflow: false,
      terminal: "",
      result: "",
      admissions: /* @__PURE__ */ new Map(),
      pending: /* @__PURE__ */ new Map(),
      resolved: /* @__PURE__ */ new Set(),
      runID: "",
      nativeTerminal: void 0,
      sequence: void 0,
      nativeScope: void 0,
      admitted: /* @__PURE__ */ new Set(),
      liveAssistants: /* @__PURE__ */ new Set(),
      attempted: /* @__PURE__ */ new Set(),
      verifying: /* @__PURE__ */ new Set()
    };
    sessions.set(sid, s);
    return s;
  }
  const ownershipToken = (s) => ({ s, generation: s.generation, lifecycle });
  const ownedToken = (token) => !disposed && lifecycle === token.lifecycle && sessions.get(token.s.sid) === token.s && token.s.generation === token.generation;
  const semanticToken = (s) => ({ ...ownershipToken(s), epoch: s.epoch, revision: s.revision });
  const current = (token) => ownedToken(token) && token.s.epoch === token.epoch && token.s.revision === token.revision;
  const liveWork = (s) => s.started && Boolean(s.user) && !s.result && !s.interrupted && !s.blocked;
  function lookup(call) {
    const controller = new AbortController(), epoch = lifecycle;
    return core.lookup(call, {
      signal: controller.signal,
      isCurrent: () => !disposed && epoch === lifecycle,
      metadataDeadline: now() + Math.min(timeout, 2e3)
    });
  }
  function ensureOwnership(s) {
    if (strict || s.ownership !== "new") return;
    s.ownership = "pending";
    const token = ownershipToken(s);
    void lookup((signal) => options.client.get({ sessionID: s.sid }, { signal })).then((info) => {
      if (!ownedToken(token)) return;
      if (info === void 0) {
        s.ownership = "unverified";
        diag("ownership_unverified");
        return;
      }
      if (!object2(info) || info.id !== s.sid || info.parentID !== void 0 && !id3(info.parentID) || !sameLocation(info.location, own2)) {
        s.ownership = "rejected";
        diag("ownership_unverified");
        return;
      }
      s.ownership = info.parentID === void 0 ? "root" : "child";
      schedule(s);
    });
  }
  async function context(s, handoff) {
    const rows2 = await core.lookup((signal) => options.client.context({ sessionID: s.sid }, { signal }), handoff);
    if (!Array.isArray(rows2) || rows2.length > 4096) {
      diag("context_unverified");
      return;
    }
    const seen = /* @__PURE__ */ new Set(), metadata = [];
    for (const row of rows2) {
      if (!object2(row) || !id3(row.id) || seen.has(row.id) || typeof row.type !== "string") {
        diag("context_unverified");
        return;
      }
      seen.add(row.id);
      metadata.push({
        id: row.id,
        type: row.type,
        finish: row.finish,
        completed: Number.isFinite(row.time?.completed),
        failed: row.error != null
      });
    }
    return metadata;
  }
  function associated(s, rows2) {
    const lastUser = rows2.findLast((row) => row.type === "user");
    return lastUser ? lastUser.id === s.user : s.compactedUser === s.user && Boolean(s.user);
  }
  async function emit(s, key2, fact, handoff) {
    if (disposed || s.ownership !== "root" || s.admitted.has(key2)) return;
    if (s.admitted.size >= 2048) {
      s.blocked = true;
      diag("admission_capacity");
      return;
    }
    s.admitted.add(key2);
    await core.emit({ version: 1, sessionID: s.sid, turnID: s.user, rootSession: true, ...fact }, handoff);
  }
  function schedule(s) {
    if (disposed || !strict && s.ownership !== "root" || !liveWork(s)) return;
    const candidates = [...s.pending.values()].filter((candidate) => !s.admitted.has(`request:${candidate.kind}:${candidate.id}`));
    if (s.terminal && !s.result) candidates.push({ kind: s.terminal, id: "", messageID: s.final });
    for (const candidate of candidates) {
      if (candidate.kind === "success" && (!s.final || s.retry || s.compacting || s.pending.size || s.admissions.size)) continue;
      const flight = `${s.epoch}:${candidate.kind}:${candidate.id}`;
      if (s.verifying.has(flight)) continue;
      const attempt = `${s.epoch}:${s.user}:${candidate.kind}:${candidate.id}:${candidate.messageID ?? ""}`;
      if (s.attempted.has(attempt)) continue;
      if (s.attempted.size >= 2048) {
        s.blocked = true;
        diag("verification_capacity");
        return;
      }
      s.attempted.add(attempt);
      const token = semanticToken(s);
      s.verifying.add(flight);
      const final = s.nativeTerminal;
      const relevant = () => strict && final && ["success", "failure"].includes(candidate.kind) ? ownedToken(token) && s.epoch === token.epoch && !s.blocked && !s.interrupted && s.nativeTerminal === final : current(token);
      const work = core.submit(s.sid, relevant, async (handoff) => {
        if (strict) await verifyStrict(s, candidate, handoff, final);
        else await verify(s, candidate, token, handoff);
      }, candidate.ingress ?? s.terminalIngress ?? now());
      if (!work) {
        s.blocked = true;
        s.pending.clear();
      }
      void work?.finally(() => {
        s.verifying.delete(flight);
        if (!strict && ownedToken(token) && !current(token)) {
          s.attempted.delete(attempt);
          schedule(s);
        }
      });
    }
  }
  async function verify(s, candidate, token, handoff) {
    const rows2 = await context(s, handoff);
    if (!current(token)) return;
    if (!rows2 || !liveWork(s) || !associated(s, rows2)) return;
    if (candidate.kind === "success") {
      if (s.terminal !== "success" || s.result || s.retry || s.compacting || s.pending.size || s.admissions.size || !s.final) return;
      const index = rows2.findIndex((row) => row.id === s.final && row.type === "assistant");
      const answer = rows2[index];
      if (!answer || answer.finish !== "stop" || !answer.completed || answer.failed || rows2.slice(index + 1).some((row) => row.type !== "idle")) return;
      s.result = "success";
      await emit(s, `terminal:${s.epoch}`, { kind: "turn_idle_verified", messageID: s.final }, handoff);
    } else if (candidate.kind === "failure") {
      if (s.terminal !== "failure" || s.result) return;
      s.result = "failure";
      await emit(s, `terminal:${s.epoch}`, { kind: "terminal_error" }, handoff);
    } else {
      if (s.pending.get(candidate.id) !== candidate || s.resolved.has(candidate.id)) return;
      if (candidate.messageID && (!s.liveAssistants.has(candidate.messageID) || !rows2.some((row) => row.type === "assistant" && row.id === candidate.messageID))) return;
      await emit(s, `request:${candidate.kind}:${candidate.id}`, { kind: candidate.kind, requestID: candidate.id }, handoff);
    }
  }
  function matches(proof, run) {
    return object2(proof) && proof.sessionID === run.sessionID && proof.turnID === run.turnID && proof.location === own2 && proof.rootSession === true;
  }
  async function verifyStrict(s, candidate, handoff, final) {
    const run = Object.freeze({
      sessionID: s.sid,
      turnID: s.runID,
      userID: s.user,
      location: own2,
      observedLocation: s.nativeScope,
      terminalEventID: final?.id,
      terminalCreated: final?.created,
      terminalSequence: final?.sequence
    });
    const scope2 = await core.lookup((signal) => options.native.session(run, signal), handoff);
    if (!handoff.isCurrent() || !matches(scope2, run)) {
      diag("root_execution_unverified");
      return;
    }
    s.ownership = "root";
    const terminal = candidate.kind === "success" || candidate.kind === "failure";
    if (terminal) {
      if (s.compacting || !candidate.messageID || !final) {
        diag("terminal_assistant_unverified");
        return;
      }
      const answer = await core.lookup((signal) => options.native.assistant({ ...run, messageID: candidate.messageID }, signal), handoff);
      if (!handoff.isCurrent() || !matches(answer, run) || answer.messageID !== candidate.messageID || answer.role !== "assistant" || answer.summary !== false || answer.final !== true || answer.outcome !== (candidate.kind === "failure" ? "error" : "success")) {
        diag("terminal_assistant_unverified");
        return;
      }
    } else if (candidate.kind === "question_asked") {
      const source = await core.lookup((signal) => options.native.questionSource({
        ...run,
        requestID: candidate.id,
        messageID: candidate.messageID,
        callID: candidate.callID
      }, signal), handoff);
      if (!handoff.isCurrent() || !matches(source, run) || source.requestID !== candidate.id || source.messageID !== candidate.messageID || source.callID !== candidate.callID || source.role !== "assistant" || source.tool !== "question" || source.summary !== false) {
        diag("question_source_unverified");
        return;
      }
    }
    const kind = terminal ? candidate.kind === "success" ? "turn_idle_verified" : "terminal_error" : candidate.kind;
    const envelope = terminal ? final : candidate;
    let snapshot;
    const takeSnapshot = async () => {
      if (kind === "question_asked") return checkpoint.verify(handoff);
      const pending = await core.lookup((signal) => options.native.currentPermission({ ...run, requestID: candidate.id }, signal), handoff);
      return handoff.isCurrent() && matches(pending, run) && pending.pending === true && pending.requestID === candidate.id && pending.messageID === candidate.messageID && pending.callID === candidate.callID;
    };
    const revalidate = terminal ? void 0 : async () => {
      snapshot ??= takeSnapshot();
      return Boolean(await snapshot && handoff.isCurrent());
    };
    const fact = {
      kind,
      ...kind === "turn_idle_verified" ? { messageID: candidate.messageID } : {},
      ...!terminal ? { requestID: candidate.id } : {},
      provenance: {
        generation: "v2",
        observationID: canonicalID("v2", s.sid, s.runID, kind, terminal ? candidate.messageID : candidate.id),
        nativeEventID: envelope.eventID ?? envelope.id,
        nativeTime: envelope.created,
        timeBasis: "envelope_created"
      }
    };
    if (terminal) s.result = candidate.kind;
    await emit(s, terminal ? `terminal:${s.epoch}` : `request:${kind}:${candidate.id}`, fact, { ...handoff, revalidate });
  }
  function resetFinal(s) {
    s.final = "";
    s.terminal = "";
  }
  function block(s) {
    s.blocked = true;
    resetFinal(s);
    s.revision++;
    diag("metadata_capacity");
  }
  function suppress(sid, code) {
    const s = sessions.get(sid);
    if (s) {
      s.blocked = true;
      s.pending.clear();
      s.revision++;
    }
    diag(code);
  }
  function observe(event) {
    const ingress = now();
    try {
      ingest(event, ingress);
    } finally {
      if (strict) core.recheck();
    }
  }
  function ingest(event, ingress) {
    if (disposed) return;
    if (!object2(event) || typeof event.type !== "string" || !object2(event.data)) {
      if (strict && supported.has(event?.type)) fence("invalid_native_envelope");
      else diag("invalid_event");
      return;
    }
    const type = event.type;
    let p = event.data, correlation;
    if (strict && checkpoint?.consume(event)) return;
    if (type === "location.shutdown") {
      if (strict) {
        let scope2;
        try {
          scope2 = options.native.correlate(event)?.location;
        } catch {
        }
        if (scope2 === void 0 || scope2 === own2) fence("location_shutdown");
        return;
      }
      if (sameLocation(event.location, own2)) dispose();
      return;
    }
    if (!supported.has(type) && !(strict && type.startsWith("session."))) return;
    if (strict) {
      try {
        correlation = options.native.correlate(event);
      } catch {
        if (id3(p.sessionID)) suppress(p.sessionID, "native_mapping_failed");
        else fence("native_mapping_failed");
        return;
      }
      if (!correlation) return;
      const sid2 = correlation.sessionID;
      if (sid2 === "global") return;
      if (!id3(sid2)) {
        fence("native_correlation_unverified");
        return;
      }
      if (!id3(event.id) || !timestamp(event.created)) {
        suppress(sid2, "invalid_native_envelope");
        return;
      }
      p = { ...p, sessionID: sid2 };
      if (correlation.messageID) p.assistantMessageID = correlation.messageID;
    }
    const sid = strict ? correlation.sessionID : type === "form.created" ? p.form?.sessionID : p.sessionID;
    if (!id3(sid) || sid === "global") {
      diag("invalid_session");
      return;
    }
    if (type === "session.moved" || type === "session.deleted") {
      const tracked = sessions.get(sid);
      if (tracked) {
        if (strict) {
          tracked.blocked = true;
          tracked.pending.clear();
          tracked.nativeScope = correlation.location;
          tracked.revision++;
        } else invalidate(tracked);
      }
      return;
    }
    if (!strict && event.location !== void 0 && !sameLocation(event.location, own2)) return;
    if (strict && correlation.location !== void 0 && correlation.location !== own2) {
      const tracked = sessions.get(sid);
      if (tracked) {
        tracked.blocked = true;
        tracked.pending.clear();
        tracked.revision++;
      }
      diag("scope_mismatch");
      return;
    }
    if (event.id !== void 0) {
      if (!id3(event.id)) {
        diag("invalid_event");
        return;
      }
      if (!strict && eventIDs.has(event.id)) return;
      if (!strict) {
        eventIDs.set(event.id, true);
        if (eventIDs.size > 2048) eventIDs.delete(eventIDs.keys().next().value);
      }
    }
    const s = state(sid);
    if (!s) return;
    if (s.ownership === "rejected" || s.ownership === "child") return;
    if (strict) {
      if (type.startsWith("session.step.") && !id3(correlation.messageID) && correlation.compaction !== true) {
        suppress(sid, "native_correlation_unverified");
        return;
      }
      const badCorrelation = ["location", "messageID", "requestID", "callID"].some((key2) => correlation[key2] !== void 0 && !id3(correlation[key2]));
      const seq = correlation.sequence;
      if (badCorrelation || seq !== void 0 && (!object2(seq) || seq.aggregate !== sid || !Number.isSafeInteger(seq.seq) || seq.seq < 0 || seq.version !== void 0 && (!Number.isSafeInteger(seq.version) || seq.version < 0)) || correlation.compaction !== void 0 && typeof correlation.compaction !== "boolean") {
        s.blocked = true;
        s.pending.clear();
        s.revision++;
        diag("native_correlation_unverified");
        return;
      }
      const nativeSequence = seq ? { aggregate: seq.aggregate, seq: seq.seq, ...seq.version !== void 0 ? { version: seq.version } : {} } : void 0;
      if (s.nativeScope !== void 0 && correlation.location === void 0 && s.nativeScope !== own2) {
        s.blocked = true;
        diag("scope_mismatch");
        return;
      }
      const fingerprint = JSON.stringify([
        type,
        event.created,
        sid,
        correlation.location,
        correlation.messageID,
        correlation.requestID,
        correlation.callID,
        correlation.compaction,
        nativeSequence,
        id3(p.inboxID) ? p.inboxID : void 0,
        id3(p.item?.type) ? p.item.type : void 0,
        p.item?.delivery === "queue",
        p.delivery === "queue",
        p.finish === "stop"
      ]);
      if (eventIDs.has(event.id)) {
        if (eventIDs.get(event.id) === fingerprint) return;
        const original = sessions.get(JSON.parse(eventIDs.get(event.id))[2]);
        if (original) {
          original.blocked = true;
          original.pending.clear();
          original.revision++;
        }
        s.blocked = true;
        s.pending.clear();
        s.revision++;
        diag("native_identity_contradiction");
        return;
      }
      eventIDs.set(event.id, fingerprint);
      if (eventIDs.size > 2048) eventIDs.delete(eventIDs.keys().next().value);
      if (s.nativeTerminal && ["session.inbox.enqueued", "session.inbox.delivered", "session.step.started"].includes(type)) {
        s.blocked = true;
        s.pending.clear();
        s.revision++;
      }
      if (type.startsWith("session.") && (!object2(seq) || seq.aggregate !== sid || !Number.isSafeInteger(seq.seq) || seq.seq < 0)) {
        s.blocked = true;
        s.pending.clear();
        s.revision++;
        diag("invalid_native_sequence");
        return;
      }
      if (seq) {
        if (s.sequence && seq.seq <= s.sequence.seq) {
          s.blocked = true;
          s.pending.clear();
          s.revision++;
          diag("native_sequence_contradiction");
          return;
        }
        s.sequence = {
          ...nativeSequence,
          id: event.id,
          type,
          created: event.created,
          messageID: correlation.messageID,
          compaction: correlation.compaction
        };
      }
      if (correlation.location !== void 0) s.nativeScope = correlation.location;
      if (["session.retry.scheduled", "session.compaction.started", "session.execution.interrupted"].includes(type) || correlation.compaction === true || type === "session.execution.started") {
        for (const key2 of s.pending.keys()) s.resolved.add(key2);
        s.pending.clear();
      }
      if (correlation.compaction === true) s.compacting = true;
      if (s.resolved.size >= 256) {
        s.blocked = true;
        diag("request_capacity");
        return;
      }
    }
    let changed = true;
    if (type === "session.execution.started") {
      if (s.ownership === "unverified") s.ownership = "new";
      s.runID = strict ? event.id : "";
      s.nativeTerminal = void 0;
      s.epoch++;
      s.started = true;
      s.user = "";
      s.assistant = "";
      resetFinal(s);
      s.retry = false;
      s.interrupted = false;
      s.compacting = false;
      s.compactedUser = "";
      s.result = "";
      s.blocked = s.admissionsOverflow;
      s.admitted.clear();
      s.pending.clear();
      s.liveAssistants.clear();
      s.attempted.clear();
    } else if (type === "session.inbox.enqueued") {
      if (!id3(p.inboxID) || !object2(p.item) || !id3(p.item.type)) {
        diag("invalid_inbox");
        return;
      }
      if (s.admissions.size >= 64 && !s.admissions.has(p.inboxID)) {
        s.admissionsOverflow = true;
        block(s);
      } else s.admissions.set(p.inboxID, { type: p.item.type, delivery: p.item.delivery === "queue" ? "queue" : "steer" });
      resetFinal(s);
    } else if (type === "session.inbox.delivered") {
      if (!id3(p.inboxID)) {
        diag("invalid_inbox");
        return;
      }
      const item = s.admissions.get(p.inboxID);
      s.admissions.delete(p.inboxID);
      if (!item) {
        s.blocked = true;
        diag("unmatched_delivery");
      } else if (item.type === "user" && s.started) {
        s.user = p.inboxID;
        s.assistant = "";
        s.liveAssistants.clear();
        s.compactedUser = "";
        s.retry = false;
      }
      resetFinal(s);
    } else if (type === "session.inbox.cancelled") {
      if (id3(p.inboxID)) s.admissions.delete(p.inboxID);
    } else if (type === "session.inbox.delivery.changed") {
      const admission = s.admissions.get(p.inboxID);
      if (admission && ["steer", "queue"].includes(p.delivery)) admission.delivery = p.delivery;
    } else if (type === "session.step.started") {
      if (strict && correlation.compaction === true) {
        s.compacting = true;
        resetFinal(s);
        s.revision++;
        return;
      }
      if (!id3(p.assistantMessageID) || !liveWork(s)) {
        diag("unmatched_step");
        return;
      }
      if (strict) s.compacting = false;
      if (strict && s.assistant && s.assistant !== p.assistantMessageID) {
        for (const key2 of s.pending.keys()) s.resolved.add(key2);
        s.pending.clear();
      }
      s.assistant = p.assistantMessageID;
      retainedAdd(s.liveAssistants, p.assistantMessageID, 64);
      s.retry = false;
      resetFinal(s);
    } else if (type === "session.step.ended") {
      if (strict && correlation.compaction === true) {
        s.compacting = true;
        resetFinal(s);
        s.revision++;
        return;
      }
      if (!id3(p.assistantMessageID) || p.assistantMessageID !== s.assistant || !liveWork(s)) return;
      s.final = (strict || p.finish === "stop") && !s.retry && !s.compacting ? p.assistantMessageID : "";
    } else if (type === "session.step.failed" || type === "session.retry.scheduled") {
      resetFinal(s);
      s.retry = type === "session.retry.scheduled";
      if (strict && type === "session.step.failed" && !s.compacting && p.assistantMessageID === s.assistant && id3(p.assistantMessageID)) s.final = p.assistantMessageID;
    } else if (type === "session.compaction.started") {
      s.compacting = true;
      resetFinal(s);
    } else if (type === "session.compaction.ended") {
      if (s.compacting && liveWork(s)) s.compactedUser = s.user;
      s.compacting = false;
      resetFinal(s);
    } else if (type === "session.compaction.failed") {
      s.compacting = false;
      resetFinal(s);
    } else if (type === "session.execution.interrupted") {
      s.interrupted = true;
      resetFinal(s);
      s.pending.clear();
    } else if (type === "session.execution.succeeded") {
      if (strict && s.nativeTerminal) {
        s.blocked = true;
        s.revision++;
        diag("native_terminal_contradiction");
        return;
      }
      s.terminal = "success";
    } else if (type === "session.execution.failed") {
      if (strict && s.nativeTerminal) {
        s.blocked = true;
        s.revision++;
        diag("native_terminal_contradiction");
        return;
      }
      if (!strict && !object2(p.error)) {
        diag("invalid_failure");
        return;
      }
      const tag = p.error?._tag ?? p.error?.name ?? p.error?.type;
      if (typeof tag === "string" && /abort|cancel|interrupt/i.test(tag)) {
        s.interrupted = true;
        resetFinal(s);
      } else s.terminal = "failure";
    } else if (type === "form.replied" || type === "form.cancelled" || type === "permission.replied") {
      const rid = strict ? correlation.requestID : type === "permission.replied" ? p.requestID : p.id;
      if (!id3(rid)) {
        diag("invalid_request");
        return;
      }
      retainedAdd(s.resolved, rid, strict ? 256 : 2048);
      s.pending.delete(rid);
      resetFinal(s);
    } else if (type === "form.created" || type === "permission.asked") {
      let rid, messageID, kind;
      if (strict) {
        rid = correlation.requestID;
        messageID = correlation.messageID;
        kind = type === "form.created" ? "question_asked" : "permission_asked";
        if (!id3(rid) || !id3(messageID) || !id3(correlation.callID) || messageID !== s.assistant || !s.liveAssistants.has(messageID)) {
          s.blocked = true;
          s.pending.clear();
          s.revision++;
          diag("request_identity_unverified");
          return;
        }
      } else if (type === "form.created") {
        const form = p.form;
        if (!object2(form) || form.metadata?.kind !== "question" || !id3(form.id) || !Array.isArray(form.fields) || form.fields.length === 0 || !id3(form.metadata?.tool?.messageID) || !id3(form.metadata?.tool?.id)) return;
        rid = form.id;
        messageID = form.metadata.tool.messageID;
        kind = "question_asked";
      } else {
        if (!id3(p.id) || typeof p.action !== "string" || !p.action || !Array.isArray(p.resources) || p.source !== void 0 && (!object2(p.source) || p.source.type !== "tool" || !id3(p.source.messageID) || !id3(p.source.id))) return;
        rid = p.id;
        messageID = p.source?.messageID;
        kind = "permission_asked";
      }
      if (strict && s.pending.has(rid)) {
        const previous = s.pending.get(rid);
        if (previous.eventID !== event.id || previous.created !== event.created || previous.messageID !== messageID || previous.callID !== correlation.callID) {
          suppress(sid, "request_identity_ambiguous");
        }
        return;
      }
      if (strict && type === "form.created" && (!checkpoint?.ready() || !options.native.questionSource)) {
        s.resolved.add(rid);
        diag(!checkpoint?.ready() ? "form_checkpoint_unready" : "question_source_unavailable");
        return;
      }
      if (strict && type === "permission.asked" && !options.native.currentPermission) {
        diag("permission_pending_authority_unavailable");
        return;
      }
      if (!liveWork(s) || s.resolved.has(rid) || s.pending.has(rid) || strict && (s.nativeTerminal || s.compacting || !id3(correlation.callID))) return;
      if (s.pending.size >= 64 || strict && s.pending.size + s.resolved.size >= 256) block(s);
      else s.pending.set(rid, {
        id: rid,
        messageID,
        kind,
        ingress,
        ...strict ? { callID: correlation.callID, eventID: event.id, created: event.created } : {}
      });
      resetFinal(s);
    } else changed = false;
    if (strict && ["session.execution.succeeded", "session.execution.failed"].includes(type)) {
      s.pending.clear();
      s.nativeTerminal = Object.freeze({ id: event.id, created: event.created, sequence: Object.freeze({ ...s.sequence }) });
      s.terminalIngress = ingress;
      if (s.compacting) {
        s.terminal = "";
        diag("compaction_terminal_suppressed");
      }
    }
    if (s.admissionsOverflow && ["session.execution.succeeded", "session.execution.failed", "session.execution.interrupted"].includes(type)) {
      s.admissionsOverflow = false;
      s.admissions.clear();
    }
    if (changed) s.revision++;
    ensureOwnership(s);
    schedule(s);
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    lifecycle++;
    core.invalidate();
    sessions.clear();
    eventIDs.clear();
  }
  return {
    observe,
    dispose,
    core,
    diag,
    setCheckpoint(value) {
      checkpoint = value;
    },
    invalidate() {
      lifecycle++;
      core.invalidate();
      checkpoint?.invalidate();
      for (const s of sessions.values()) {
        s.blocked = true;
        s.pending.clear();
        s.revision++;
      }
    },
    done: () => core.drain()
  };
}

// node_modules/universal-agent-plugins-opencode-events/checkpoint.js
import { randomBytes } from "node:crypto";
function createCheckpoint(port, core, fail2) {
  let current;
  function invalidate() {
    const state = current;
    if (!state) return;
    state.ready = false;
    for (const resolve2 of state.waiters.values()) resolve2(false);
    state.waiters.clear();
    state.retired.clear();
  }
  function consume(envelope) {
    const state = current;
    if (!state?.registration || state.signal.aborted || envelope.type !== state.registration.type) return false;
    let nonce;
    try {
      nonce = state.registration.read(envelope);
    } catch {
      fail2("checkpoint_schema_unverified");
      return true;
    }
    if (nonce === void 0) {
      fail2("checkpoint_schema_unverified");
      return true;
    }
    if (state.retired.delete(nonce)) return true;
    if (typeof nonce !== "string" || !/^[a-f0-9]{32}$/.test(nonce) || !state.waiters.has(nonce)) {
      fail2("checkpoint_continuity_unverified");
      return true;
    }
    const resolve2 = state.waiters.get(nonce);
    state.waiters.delete(nonce);
    resolve2(true);
    return true;
  }
  async function marker2(state, handoff) {
    if (state !== current || !handoff.isCurrent() || !state.registration) return false;
    const result = await core.lookup(async (signal) => {
      const nonce = randomBytes(16).toString("hex");
      let finish, wasConsumed = false;
      const consumed = new Promise((resolve2) => {
        finish = (value) => {
          if (value) wasConsumed = true;
          resolve2(value);
        };
        state.waiters.set(nonce, finish);
      });
      const abort = () => finish(false);
      signal.addEventListener("abort", abort, { once: true });
      try {
        if (signal.aborted) return false;
        await state.registration.emit(nonce);
        return await consumed;
      } finally {
        state.waiters.delete(nonce);
        if (!wasConsumed && !state.signal.aborted && state === current) {
          if (state.retired.size >= 256) fail2("checkpoint_capacity");
          else state.retired.add(nonce);
        }
        signal.removeEventListener("abort", abort);
      }
    }, handoff);
    if (!handoff.isCurrent()) return false;
    if (!result || state !== current) {
      if (state === current && !state.signal.aborted) fail2("checkpoint_failed");
      return false;
    }
    return true;
  }
  async function open(signal) {
    invalidate();
    const state = { signal, ready: false, registration: void 0, waiters: /* @__PURE__ */ new Map(), retired: /* @__PURE__ */ new Set() };
    current = state;
    if (!port) {
      core.diag("form_checkpoint_unavailable");
      return;
    }
    const handoff = {
      signal,
      isCurrent: () => current === state && !signal.aborted,
      metadataDeadline: core.now() + 2e3
    };
    const registration = await core.lookup(async () => {
      const owned = await port.register(signal, randomBytes(16).toString("hex"));
      if (!handoff.isCurrent()) {
        await owned?.dispose?.();
        return;
      }
      state.registration = owned;
      return owned;
    }, handoff);
    if (!handoff.isCurrent()) return;
    if (!registration || typeof registration.emit !== "function" || typeof registration.read !== "function" || typeof registration.dispose !== "function" || !id(registration.type)) {
      fail2("checkpoint_registration_unverified");
      return;
    }
    if (await marker2(state, handoff)) state.ready = true;
  }
  async function close() {
    invalidate();
    const state = current;
    current = void 0;
    if (state?.registration) {
      try {
        await state.registration.dispose();
      } catch {
        core.diag("checkpoint_dispose_failed");
      }
    }
  }
  return {
    open,
    close,
    consume,
    invalidate,
    ready: () => Boolean(current?.ready && !current.signal.aborted),
    async verify(handoff) {
      const state = current;
      return Boolean(state?.ready && await marker2(state, handoff) && state.ready);
    }
  };
}

// node_modules/universal-agent-plugins-opencode-events/v2.js
function createV2Observer(options) {
  if (typeof options?.context?.event?.subscribe !== "function" || typeof options.emit !== "function" || typeof options.runtimeEligibility !== "function" || typeof options.native?.correlate !== "function" || typeof options.native?.session !== "function" || typeof options.native?.assistant !== "function" || !id(options.location)) {
    throw new TypeError("context, native ports, location, runtimeEligibility and emit required");
  }
  const lifetime = new AbortController();
  let connection, started = false, task = Promise.resolve(), replacements = 0;
  function invalidate(reason) {
    reducer.invalidate();
    connection?.abort();
    reducer.diag(reason);
  }
  const reducer = createV2Reducer(options, true, invalidate), core = reducer.core;
  const checkpoint = createCheckpoint(options.checkpoint, core, invalidate);
  reducer.setCheckpoint(checkpoint);
  async function delay(ms) {
    await new Promise((resolve2) => {
      const done = () => {
        clearTimeout(timer);
        lifetime.signal.removeEventListener("abort", done);
        resolve2();
      };
      const timer = setTimeout(done, ms);
      lifetime.signal.addEventListener("abort", done, { once: true });
      if (lifetime.signal.aborted) done();
    });
  }
  async function read() {
    while (!lifetime.signal.aborted) {
      connection = new AbortController();
      try {
        const stream = options.context.event.subscribe({ signal: connection.signal });
        const opening = Promise.resolve().then(() => checkpoint.open(connection.signal));
        for await (const event of stream) {
          if (lifetime.signal.aborted || connection.signal.aborted) break;
          reducer.observe(event);
          if (connection.signal.aborted) break;
        }
        if (!lifetime.signal.aborted) invalidate("subscription_ended");
        await opening;
      } catch {
        if (!lifetime.signal.aborted) invalidate("subscription_error");
      }
      connection.abort();
      await checkpoint.close();
      if (lifetime.signal.aborted || replacements >= 3) break;
      await delay([250, 1e3, 2e3][replacements++]);
    }
    if (!lifetime.signal.aborted) core.diag("subscription_replacements_exhausted");
  }
  return {
    start() {
      if (started || lifetime.signal.aborted) return;
      started = true;
      let eligibility;
      try {
        eligibility = options.runtimeEligibility(options.context.app?.version);
      } catch {
      }
      if (eligibility !== "supported") {
        core.diag(eligibility === "unsupported" ? "runtime_unsupported" : "runtime_unverified");
        return;
      }
      task = read();
    },
    dispose() {
      invalidate("observer_disposed");
      lifetime.abort();
      reducer.dispose();
    },
    async done() {
      await task;
      await core.drain();
    }
  };
}

// candidate/native-v1.mjs
var id4 = (x) => typeof x === "string" && x.length > 0 && !/[\u0000-\u001f]/u.test(x) && Buffer.byteLength(x) <= 256;
var stamp = (x) => Number.isSafeInteger(x) && x > 0;
function createNativeV1(client, directory, fail2) {
  const requests = /* @__PURE__ */ new Map(), users = /* @__PURE__ */ new Map();
  function ingest(event) {
    const p = event?.properties;
    if (event?.type === "message.updated" && p?.info?.role === "user") {
      const { sessionID, id: userID, time } = p.info;
      if (!id4(sessionID) || !id4(userID) || !stamp(time?.created)) {
        fail2();
        return;
      }
      const prior = users.get(sessionID), created = time.created;
      if (prior?.seen.has(userID)) {
        if (prior.seen.get(userID) !== created) fail2();
        return;
      }
      if (prior && created < prior.created) return;
      if (prior?.seen.size >= 512 || !prior && users.size >= 512) {
        fail2();
        return;
      }
      const seen = prior?.seen ?? /* @__PURE__ */ new Map();
      seen.set(userID, created);
      users.set(sessionID, { id: userID, created, seen });
    }
    if (["question.asked", "permission.asked"].includes(event?.type) && id4(p?.id)) {
      if (requests.size >= 256 && !requests.has(p.id)) {
        fail2();
        return;
      }
      const next = {
        sessionID: p.sessionID,
        messageID: p.tool?.messageID ?? p.messageID,
        callID: p.tool?.callID,
        turnID: users.get(p.sessionID)?.id
      };
      const prior = requests.get(p.id);
      if (prior && Object.keys(next).some((key2) => prior[key2] !== next[key2])) {
        fail2();
        return;
      }
      if (!prior) requests.set(p.id, Object.freeze(next));
    }
    if (["question.replied", "question.rejected", "permission.replied"].includes(event?.type)) requests.delete(p?.requestID);
    if (["session.deleted", "session.compacted", "session.error"].includes(event?.type) || event?.type === "session.status" && p?.status?.type === "retry") {
      const sid = p?.sessionID ?? p?.info?.id;
      for (const [key2, value] of requests) if (value.sessionID === sid) requests.delete(key2);
    }
  }
  async function finalize(event, handoff) {
    if (!handoff.isCurrent() || handoff.signal.aborted || users.get(event.sessionID)?.id !== event.turnID) return false;
    const request = event.requestID ? requests.get(event.requestID) : void 0;
    if (event.requestID && (!request || request.sessionID !== event.sessionID || request.turnID !== event.turnID || !id4(request.messageID) || !id4(request.callID))) return false;
    const result = await client.session.get({ path: { id: event.sessionID }, signal: handoff.signal });
    if (!handoff.isCurrent() || handoff.signal.aborted) return false;
    const info = result?.data ?? result;
    if (info?.id !== event.sessionID || info.parentID !== void 0 || info.directory !== directory) return false;
    const snapshot = await client.session.messages({ path: { id: event.sessionID }, query: { limit: 30 }, signal: handoff.signal });
    if (!handoff.isCurrent() || handoff.signal.aborted || users.get(event.sessionID)?.id !== event.turnID || request && requests.get(event.requestID) !== request) return false;
    const rows2 = Array.isArray(snapshot) ? snapshot : snapshot?.data;
    if (!Array.isArray(rows2) || rows2.length > 30) return false;
    const messages = rows2.map((row) => row?.info ?? row);
    if (!messages.every((row) => id4(row?.id) && row.sessionID === event.sessionID)) return false;
    const answer = messages.findLast((row) => row.role === "assistant" && row.summary !== true);
    const lastUser = messages.findLast((row) => row.role === "user");
    if (lastUser && lastUser.id !== event.turnID || !answer || answer.parentID !== event.turnID || answer.path?.cwd !== directory || messages.at(-1) !== answer || !stamp(answer.time?.created)) return false;
    if (event.kind === "turn_idle_verified") return answer.id === event.messageID && answer.finish === "stop" && answer.time?.completed === event.provenance.nativeTime && answer.error == null;
    if (event.kind === "terminal_error") return answer.id === event.provenance.nativeMessageID && answer.time.created === event.provenance.nativeTime && stamp(answer.time?.completed) && answer.error && !/abort|cancel/i.test(answer.error.name ?? "");
    return request?.messageID === answer.id && answer.time.created === event.provenance.nativeTime;
  }
  return Object.freeze({ ingest, finalize, dispose() {
    users.clear();
    requests.clear();
  } });
}

// candidate/native-v2.mjs
var id5 = (x) => typeof x === "string" && x.length > 0 && Buffer.byteLength(x) <= 256 && !/[\u0000-\u001f]/u.test(x);
var stamp2 = (x) => Number.isSafeInteger(x) && x > 0;
var cancelled = (error) => /abort|cancel|interrupt/i.test(error?._tag ?? error?.name ?? error?.type ?? "");
var scope = (x) => x && typeof x.directory === "string" ? Object.freeze({ directory: x.directory, workspaceID: x.workspaceID }) : void 0;
var same = (a, b) => a && b && a.directory === b.directory && a.workspaceID === b.workspaceID;
var rowTypes = /* @__PURE__ */ new Set([
  "user",
  "assistant",
  "compaction",
  "idle",
  "agent-switched",
  "model-switched",
  "location-switched",
  "synthetic",
  "system",
  "skill",
  "shell"
]);
var followsAssistant = (value, row) => value.slice(value.indexOf(row) + 1).some((item) => ["user", "assistant", "compaction"].includes(item.type));
var ephemeralTypes = /* @__PURE__ */ new Set([
  "session.usage.updated",
  "session.text.delta",
  "session.reasoning.delta",
  "session.tool.input.delta",
  "session.tool.progress",
  "session.compaction.delta"
]);
function createNativeV2(context, ownedLocation, onIngress, onUncertainty) {
  const own2 = scope(ownedLocation), projectID = ownedLocation?.project?.id, bindings = /* @__PURE__ */ new Map(), projected = /* @__PURE__ */ new WeakMap();
  if (!own2 || !id5(projectID)) throw new TypeError("scope_unverified");
  function reset() {
    bindings.clear();
  }
  function state(sid) {
    if (!bindings.has(sid)) {
      if (bindings.size >= 512) {
        onUncertainty();
        return;
      }
      bindings.set(sid, { forms: /* @__PURE__ */ new Map(), requests: /* @__PURE__ */ new Map(), inbox: /* @__PURE__ */ new Map() });
    }
    return bindings.get(sid);
  }
  function correlate(event) {
    const { type, data: p } = event;
    if (ephemeralTypes.has(type)) return;
    if (type === "location.shutdown") return { location: scope(event.location)?.directory };
    const sid = type === "form.created" ? p.form?.sessionID : p.sessionID;
    if (!id5(sid) || sid === "global") return;
    if (type === "form.created" && p.form?.metadata?.kind !== "question") return;
    onIngress(event);
    const b = state(sid);
    if (!b) return { sessionID: sid };
    const nativeScope = scope(event.location) ?? scope(p.location);
    if (nativeScope) b.scope = nativeScope;
    if (["session.moved", "session.deleted"].includes(type)) {
      b.run = void 0;
      b.forms.clear();
      b.requests.clear();
    }
    if (type === "session.execution.started") {
      b.run = event.id;
      b.user = void 0;
      b.assistant = void 0;
      b.step = void 0;
      b.terminal = void 0;
      b.forms.clear();
      b.requests.clear();
    }
    if (type === "session.inbox.enqueued" && id5(p.inboxID) && id5(p.item?.type)) {
      if (b.inbox.size >= 64 && !b.inbox.has(p.inboxID)) {
        onUncertainty();
        return { sessionID: sid };
      }
      if (b.inbox.has(p.inboxID) && b.inbox.get(p.inboxID) !== p.item.type) {
        onUncertainty();
        return { sessionID: sid };
      }
      b.inbox.set(p.inboxID, p.item.type);
    }
    if (type === "session.inbox.delivered") {
      const kind = b.inbox.get(p.inboxID);
      b.inbox.delete(p.inboxID);
      if (kind === "user") b.user = p.inboxID;
    }
    if (type === "session.inbox.cancelled") b.inbox.delete(p.inboxID);
    const compaction = type.startsWith("session.compaction.") || p.type === "compaction";
    if (type === "session.step.started") {
      b.assistant = compaction ? void 0 : p.assistantMessageID;
      b.step = void 0;
      b.forms.clear();
      b.requests.clear();
    }
    if (["session.step.ended", "session.step.failed"].includes(type)) b.step = Object.freeze({
      type,
      eventID: event.id,
      messageID: p.assistantMessageID,
      compaction
    });
    if (["session.execution.succeeded", "session.execution.failed"].includes(type)) {
      b.terminal = Object.freeze({ id: event.id, type, created: event.created, run: b.run, assistant: b.assistant, step: b.step });
      b.forms.clear();
      b.requests.clear();
    }
    if (["session.retry.scheduled", "session.execution.interrupted", "session.compaction.started"].includes(type) || compaction) {
      b.forms.clear();
      b.requests.clear();
    }
    let requestID, messageID, callID;
    if (type === "form.created") {
      const form = p.form;
      requestID = form.id;
      messageID = form.metadata?.tool?.messageID;
      callID = form.metadata?.tool?.id;
      if (id5(requestID) && id5(messageID) && id5(callID) && Array.isArray(form.fields) && form.fields.length > 0) {
        if (b.forms.size >= 64) {
          onUncertainty();
          return { sessionID: sid };
        }
        b.forms.set(requestID, Object.freeze({
          requestID,
          messageID,
          callID,
          run: b.run,
          eventID: event.id,
          created: event.created,
          tool: "question"
        }));
      }
    } else if (type === "permission.asked") {
      requestID = p.id;
      if (p.source?.type === "tool") {
        messageID = p.source.messageID;
        callID = p.source.id;
      }
    } else if (["form.replied", "form.cancelled", "permission.replied"].includes(type)) {
      requestID = type === "permission.replied" ? p.requestID : p.id;
      b.forms.delete(requestID);
      b.requests.delete(requestID);
    } else messageID = p.assistantMessageID;
    if (["form.created", "permission.asked"].includes(type) && id5(requestID) && id5(messageID) && id5(callID)) {
      if (b.requests.size >= 64) {
        onUncertainty();
        return { sessionID: sid };
      }
      b.requests.set(requestID, Object.freeze({ eventID: event.id, created: event.created, run: b.run, messageID, callID }));
    }
    const durable = event.durable;
    return {
      sessionID: sid,
      ...nativeScope ? { location: nativeScope.directory } : {},
      ...messageID !== void 0 ? { messageID } : {},
      ...requestID !== void 0 ? { requestID } : {},
      ...callID !== void 0 ? { callID } : {},
      ...compaction ? { compaction: true } : {},
      ...durable ? { sequence: { aggregate: durable.aggregateID, seq: durable.seq, version: durable.version } } : {}
    };
  }
  const binding = (run) => {
    const b = bindings.get(run.sessionID);
    return b && b.run === run.turnID && b.user === run.userID && b.assistant && (!run.terminalEventID || b.terminal?.id === run.terminalEventID && b.terminal?.created === run.terminalCreated) ? b : void 0;
  };
  async function session(run, signal) {
    const b = binding(run);
    if (!b || signal.aborted) return;
    const info = await context.session.get({ sessionID: run.sessionID });
    if (signal.aborted || binding(run) !== b || info?.id !== run.sessionID || info.parentID !== void 0 && !id5(info.parentID)) return;
    const observed = b.scope;
    const native = scope(info.location);
    if (!native || native.directory !== own2.directory || info.projectID !== projectID || observed && !same(observed, own2) || own2.workspaceID !== void 0 && !same(observed, own2) || native.workspaceID !== void 0 && native.workspaceID !== own2.workspaceID) return;
    return Object.freeze({ ...run, location: native.directory, rootSession: info.parentID === void 0 });
  }
  async function rows2(run, signal) {
    const b = binding(run);
    if (!b || signal.aborted) return;
    const value = await context.session.context({ sessionID: run.sessionID });
    if (signal.aborted || binding(run) !== b || !Array.isArray(value) || value.length > 4096) return;
    const seen = /* @__PURE__ */ new Set();
    for (const row of value) {
      if (!id5(row?.id) || seen.has(row.id) || !rowTypes.has(row.type) || row.sessionID !== void 0 && row.sessionID !== run.sessionID) return;
      seen.add(row.id);
    }
    if (value.findLast((row) => row.type === "user")?.id !== b.user) return;
    return value;
  }
  async function assistant(run, signal) {
    const proof = await session(run, signal);
    if (!proof?.rootSession) return;
    const b = binding(run), value = await rows2(run, signal);
    if (!value || signal.aborted || binding(run) !== b || b.assistant !== run.messageID) return;
    const terminal = b.terminal, step = terminal?.step;
    const row = value.find((item) => item.id === run.messageID);
    const terminalMessageID = terminal?.id.startsWith("evt_") ? `msg_${terminal.id.slice(4)}` : void 0;
    if (row?.type !== "assistant" || !stamp2(row.time?.completed) || !stamp2(row.time?.created) || followsAssistant(value, row) || step?.messageID !== row.id || step.compaction || !terminalMessageID || value.findIndex((item) => item.type === "idle" && item.id === terminalMessageID) <= value.indexOf(row)) return;
    let outcome;
    if (terminal.type === "session.execution.succeeded" && step.type === "session.step.ended" && row.finish === "stop" && row.error == null) outcome = "success";
    if (terminal.type === "session.execution.failed" && row.error && !cancelled(row.error)) outcome = "error";
    if (!outcome) return;
    return Object.freeze({ ...proof, messageID: row.id, role: "assistant", summary: false, final: true, outcome });
  }
  async function questionSource(run, signal) {
    const b = binding(run), form = b?.forms.get(run.requestID);
    if (!form || form.run !== run.turnID || form.messageID !== run.messageID || form.callID !== run.callID) return;
    const proof = await session(run, signal), value = await rows2(run, signal);
    if (!proof?.rootSession || !value || signal.aborted || binding(run) !== b || b.forms.get(run.requestID) !== form || !value.some((row) => row.type === "assistant" && row.id === form.messageID && !followsAssistant(value, row))) return;
    const assistant2 = value.find((row) => row.id === form.messageID && row.type === "assistant");
    if (!Array.isArray(assistant2?.content) || assistant2.content.length > 256) return;
    const tools = assistant2.content.filter((part) => part?.type === "tool" && part.id === form.callID);
    if (tools.length !== 1 || tools[0].name !== "question") return;
    return Object.freeze({
      ...proof,
      requestID: form.requestID,
      messageID: form.messageID,
      callID: form.callID,
      role: "assistant",
      tool: tools[0].name,
      summary: false
    });
  }
  async function currentPermission(run, signal) {
    const b = binding(run);
    if (!b || signal.aborted) return;
    const proof = await session(run, signal);
    if (!proof?.rootSession || signal.aborted || binding(run) !== b) return;
    const request = await context.permission.get({ sessionID: run.sessionID, requestID: run.requestID });
    if (!proof?.rootSession || signal.aborted || binding(run) !== b || request?.id !== run.requestID || request.sessionID !== run.sessionID || request.source?.type !== "tool" || request.source.messageID !== b.assistant || !id5(request.source.id)) return;
    return Object.freeze({
      ...proof,
      requestID: request.id,
      messageID: request.source.messageID,
      callID: request.source.id,
      pending: true
    });
  }
  async function finalize(event, handoff) {
    const b = bindings.get(event.sessionID);
    if (!b || !project2(event) || !handoff.isCurrent() || handoff.signal.aborted) return false;
    const run = Object.freeze({
      sessionID: event.sessionID,
      turnID: b.run,
      userID: b.user,
      location: own2.directory,
      terminalEventID: event.requestID ? void 0 : b.terminal?.id,
      terminalCreated: event.requestID ? void 0 : b.terminal?.created
    });
    const proof = await session(run, handoff.signal);
    if (!proof?.rootSession || !handoff.isCurrent() || handoff.signal.aborted) return false;
    if (!event.requestID) {
      const answer = await assistant({ ...run, messageID: b.assistant }, handoff.signal);
      return handoff.isCurrent() && answer?.final === true && answer.outcome === (event.kind === "terminal_error" ? "error" : "success");
    }
    const value = await rows2(run, handoff.signal);
    return handoff.isCurrent() && !handoff.signal.aborted && binding(run) === b && b.requests.has(event.requestID) && value?.some((row) => row.type === "assistant" && row.id === b.assistant && !followsAssistant(value, row));
  }
  function project2(event) {
    const b = bindings.get(event.sessionID);
    if (!b || !id5(b.run) || event.turnID !== b.user || event.provenance?.generation !== "v2") return;
    const source = event.requestID ? b.requests.get(event.requestID) : b.terminal;
    if (!source || source.run !== b.run || (source.eventID ?? source.id) !== event.provenance.nativeEventID || source.created !== event.provenance.nativeTime) return;
    let value = projected.get(event);
    if (!value || value.turnID !== b.run) {
      value = Object.freeze({ ...event, turnID: b.run });
      projected.set(event, value);
    }
    return value;
  }
  return Object.freeze({ native: Object.freeze({ correlate, session, assistant, questionSource, currentPermission }), reset, project: project2, finalize });
}
var checkpointNonce = (value) => typeof value === "string" && value.length === 32 && /^[a-f0-9]{32}$/.test(value);
function createRPCCheckpoint(context, ready) {
  return Object.freeze({ async register(signal, namespace) {
    if (!await ready() || signal.aborted) return;
    const id6 = `agent-notifications-${namespace}`;
    const schema = {
      type: "object",
      properties: { nonce: { type: "string", minLength: 32, maxLength: 32 } },
      required: ["nonce"],
      additionalProperties: false
    };
    const registration = await context.rpc.register({ id: id6, methods: {}, events: { checkpoint: { schema } } }, {});
    if (signal.aborted) {
      await registration.dispose();
      return;
    }
    return Object.freeze({
      type: `rpc.${id6}.checkpoint`,
      emit: async (nonce) => {
        if (!checkpointNonce(nonce)) throw new TypeError("checkpoint_nonce_invalid");
        return registration.events.emit("checkpoint", { nonce });
      },
      read: (envelope) => {
        const data = envelope?.data;
        return data && typeof data === "object" && !Array.isArray(data) && Reflect.ownKeys(data).length === 1 && Object.hasOwn(data, "nonce") && checkpointNonce(data.nonce) ? data.nonce : void 0;
      },
      dispose: () => registration.dispose()
    });
  } });
}

// consumer.mjs
import {
  readFileSync,
  realpathSync,
  statSync,
  openSync,
  fstatSync,
  closeSync,
  appendFileSync,
  writeFileSync,
  renameSync
} from "node:fs";
import { resolve, relative, isAbsolute, basename } from "node:path";
import { createHash, createHmac } from "node:crypto";
var root = realpathSync(process.env.AN_TEST_ROOT || "/missing");
var own = JSON.parse(readFileSync(resolve(root, "reader-authority-private.json")));
var marker = JSON.parse(readFileSync(resolve(root, ".owned-test-root.json")));
if (marker.purpose !== "TEST portable packaged SDK reader" || !/^TEST-/.test(basename(root))) throw Error("TEST root");
var project = realpathSync(resolve(root, "project"));
var key = readFileSync(resolve(root, "trace-key"));
var image = realpathSync(process.execPath);
var fd = openSync(image, "r");
var imageStat = fstatSync(fd, { bigint: true });
var hash = createHash("sha256").update(readFileSync(fd)).digest("hex");
var inside = (path) => !relative(root, path).startsWith("..") && !isAbsolute(relative(root, path));
if (!inside(image) || !inside(project) || hash !== own.official.executableSHA256 || own.imageSHA256 !== hash || process.platform !== { linux: "linux", darwin: "darwin", windows: "win32" }[own.os] || process.arch !== { amd64: "x64", arm64: "arm64" }[own.arch] || process.ppid !== own.parentPID || process.platform === "linux" && realpathSync("/proc/self/exe") !== image || own.directory !== project || key.length !== 32 || !["dev", "ino", "size", "mtimeNs", "ctimeNs"].every((k) => typeof imageStat[k] === "bigint")) throw Error("image custody");
var valid = true;
var fdOpen = true;
var rows = 0;
var bytes = 0;
var nativeCalls = 0;
var sdkFacts = 0;
var h = (s) => "h:" + createHmac("sha256", key).update(String(s)).digest("hex").slice(0, 24);
var safe = /* @__PURE__ */ new Set([
  "v1",
  "v2",
  "user",
  "assistant",
  "stop",
  "turn_idle_verified",
  "assistant_completed",
  "envelope_created",
  "local-performance",
  "subscription_ended",
  "subscription_error",
  "observer_disposed"
]);
function redact(value, name = "", depth = 0) {
  if (depth > 14) throw Error("trace depth");
  if (value === null || typeof value === "boolean" || typeof value === "number") return value;
  if (typeof value === "string") return safe.has(value) || name === "type" && /^[a-z][a-z0-9_.-]{0,160}$/.test(value) ? value : h(value);
  if (Array.isArray(value)) {
    if (value.length > 96) throw Error("trace array");
    return value.map((x) => redact(x, name, depth + 1));
  }
  if (value && typeof value === "object") {
    if (Object.keys(value).length > 96) throw Error("trace object");
    return Object.fromEntries(Object.entries(value).map(([k, x]) => [k, redact(x, k, depth + 1)]));
  }
  return "[unsupported]";
}
function record(kind, value = {}) {
  const line = JSON.stringify({ kind, value: redact(value) }) + "\n";
  if (++rows > 512 || (bytes += Buffer.byteLength(line)) > 1024 * 1024) {
    valid = false;
    throw Error("trace bound");
  }
  appendFileSync(resolve(root, "reader-private.jsonl"), line, { mode: 384 });
}
var exceptionRows = 0;
var exceptionBytes = 0;
function checkpointException(stage, error) {
  try {
    const text = (value, limit) => typeof value === "string" ? Buffer.from(value).subarray(0, limit).toString("utf8") : void 0;
    const row = { stage, name: text(error?.name, 64), message: text(error?.message, 1536), stack: text(error?.stack, 2048) };
    let line = JSON.stringify(row) + "\n";
    while (Buffer.byteLength(line) > 4096) {
      if (row.stack?.length) row.stack = row.stack.slice(0, Math.floor(row.stack.length / 2));
      else row.message = row.message?.slice(0, Math.floor(row.message.length / 2));
      line = JSON.stringify(row) + "\n";
    }
    const size = Buffer.byteLength(line);
    if (++exceptionRows > 8 || (exceptionBytes += size) > 16384) {
      valid = false;
      return;
    }
    appendFileSync(resolve(root, "checkpoint-errors.private.jsonl"), line, { mode: 384 });
  } catch {
    valid = false;
  }
}
function witness() {
  if (!valid || !fdOpen) return false;
  try {
    const now = fstatSync(fd, { bigint: true }), named = statSync(image, { bigint: true });
    return ["dev", "ino", "size", "mtimeNs", "ctimeNs"].every((k) => now[k] === imageStat[k] && named[k] === imageStat[k]) && (process.platform !== "linux" || realpathSync("/proc/self/exe") === image) && process.ppid === own.parentPID;
  } catch {
    return false;
  }
}
function fail(reason = "scope_uncertain") {
  valid = false;
  record("uncertainty", { reason });
}
function publish(name, value) {
  if (!witness()) throw Error("authority lost");
  const target = resolve(root, name), tmp = target + ".tmp";
  writeFileSync(tmp, JSON.stringify(value) + "\n", { mode: 384, flag: "wx" });
  renameSync(tmp, target);
}
var slots = /* @__PURE__ */ new WeakMap();
var localV1Entry = own.entry === "tui" || own.entry === "run";
if (localV1Entry && (own.mode !== "one-completion" || !["1.18.33", "1.18.34"].includes(own.version)))
  throw Error("closed V1 local entry fixture");
function scopeOK(directory) {
  try {
    return witness() && realpathSync(directory) === project;
  } catch {
    return false;
  }
}
function receipt(generation, extra = {}) {
  return {
    schemaVersion: 1,
    scope: "TEST packaged SDK reader",
    generation,
    version: own.version,
    ownedImageSHA256: hash,
    os: own.os,
    arch: own.arch,
    nativePID: process.pid,
    parentPID: process.ppid,
    actualExecPath: image,
    testAuthorityDerived: true,
    loadedMappedBytesQualified: false,
    productionQualified: false,
    installedQualified: false,
    timePolicyQualified: false,
    sourceEpochQualified: false,
    finalSpanQualified: false,
    ...extra
  };
}
function diagnostic(reason) {
  record("sdk-diagnostic", { reason });
}
async function boundedDrain(task, deadline) {
  let timer;
  try {
    return await Promise.race([task, new Promise((_, reject) => {
      timer = setTimeout(() => reject(Error("actual drain missing")), Math.max(0, deadline - performance.now()));
    })]);
  } finally {
    clearTimeout(timer);
  }
}
async function server(input) {
  if (slots.has(input.client)) return slots.get(input.client);
  if (own.version === "2.0.21" || !scopeOK(input.directory) || typeof input.client?.session?.messages !== "function" || typeof input.client?.session?.get !== "function") throw Error("V1 native context");
  const jobs = /* @__PURE__ */ new Set();
  let stopped = false, nativeCleanup = false, closing;
  const view = createNativeV1(input.client, project, fail);
  let observer;
  async function stop(native = false) {
    nativeCleanup ||= native;
    if (closing) return closing;
    const deadline = performance.now() + 2e3;
    stopped = true;
    observer.dispose();
    view.dispose();
    closing = (async () => {
      await boundedDrain(Promise.allSettled([...jobs]), deadline);
      if (jobs.size || performance.now() > deadline) throw Error("V1 drain");
      publish("reader-closed.json", receipt("v1", {
        actualSDKDispose: true,
        actualTrackedJobsSettled: true,
        nativeCallbackReader: true,
        nativeCleanupHookObserved: nativeCleanup,
        sdkFacts,
        nativeCalls,
        closureCause: own.mode === "api-only" ? "consumer_after_native_session_deleted" : "consumer_after_real_sdk_fact"
      }));
      record("reader-closed", { actualDrain: true });
      closeSync(fd);
      fdOpen = false;
    })();
    return closing;
  }
  observer = createObserver({
    client: input.client,
    location: project,
    callbackAuthority: "qualified_native_sync",
    runtimeEligibility: () => scopeOK(input.directory) ? "supported" : "unverified",
    beforeEmit: (event, handoff) => scopeOK(input.directory) && view.finalize(event, handoff),
    onDiagnostic: diagnostic,
    emit(event, handoff) {
      if (stopped || !scopeOK(input.directory) || !handoff.isCurrent() || handoff.signal.aborted || event.kind !== "turn_idle_verified" || event.rootSession !== true || ++sdkFacts !== 1) {
        fail("SDK fact rejected");
        return;
      }
      record("sdk-fact", {
        event,
        clockID: handoff.clockID,
        ingressMonotonicMs: handoff.ingressMonotonicMs,
        currentAtCallback: handoff.isCurrent(),
        nativeCallbackCount: nativeCalls
      });
      if (own.mode !== "one-completion") {
        fail("unplanned_completion_fact");
        return;
      }
      if (localV1Entry) {
        const ctrl = new AbortController(), deadline = performance.now() + 2e3;
        const job = (async () => {
          try {
            const reply = await boundedDrain(input.client.session.messages({
              path: { id: event.sessionID },
              query: { limit: 30 },
              signal: ctrl.signal
            }), deadline);
            const history = Array.isArray(reply) ? reply : reply?.data;
            if (!Array.isArray(history) || history.length > 30) throw Error("native history shape");
            const raw = JSON.stringify({ sessionID: event.sessionID, history }) + "\n";
            if (Buffer.byteLength(raw) > 1024 * 1024) throw Error("native history bound");
            if (!scopeOK(input.directory)) throw Error("native history scope lost");
            writeFileSync(resolve(root, "reader-history-private.json"), raw, { mode: 384, flag: "wx" });
            record("independent-native-history", { entry: own.entry, messages: history.length });
          } finally {
            ctrl.abort();
          }
        })();
        jobs.add(job);
        void job.then(() => {
          jobs.delete(job);
          return stop();
        }, () => {
          jobs.delete(job);
          fail("native_history_missing");
          return stop();
        }).catch(() => fail("consumer_dispose_failed"));
      } else queueMicrotask(() => void stop().catch(() => fail("consumer_dispose_failed")));
    }
  });
  const hooks = { event({ event }) {
    if (stopped) {
      record("after-dispose-native", { type: event?.type });
      return;
    }
    if (!scopeOK(input.directory)) {
      fail();
      observer.dispose();
      return;
    }
    nativeCalls++;
    record("native-v1", event);
    view.ingest(event);
    if (jobs.size >= 256) {
      fail("job_capacity");
      observer.dispose();
      return;
    }
    const job = observer.observe(event);
    jobs.add(job);
    Promise.resolve(job).finally(() => {
      jobs.delete(job);
      if (own.mode === "api-only" && event?.type === "session.deleted")
        queueMicrotask(() => void stop().catch(() => fail("consumer_dispose_failed")));
    }).catch(() => fail("callback_failure"));
    record("sdk-observe-invoked", { type: event?.type });
  }, async dispose() {
    record("native-cleanup-enter", { entry: own.entry ?? "serve" });
    await stop(true);
    record("native-cleanup-return", { entry: own.entry ?? "serve", actualTrackedJobsSettled: jobs.size === 0 });
  } };
  slots.set(input.client, hooks);
  record("loader", { branch: "v1", scopeVerified: true });
  publish("reader-ready.json", receipt("v1", { nativeCallbackReady: true }));
  return hooks;
}
async function setup(ctx) {
  if (slots.has(ctx)) return slots.get(ctx);
  if (own.version !== "2.0.21" || ctx.app?.version !== own.version || !scopeOK(ctx.location?.directory) || !ctx.location?.project?.id || typeof ctx.event?.subscribe !== "function" || typeof ctx.rpc?.register !== "function" || typeof ctx.session?.get !== "function" || typeof ctx.session?.context !== "function") throw Error("V2 native context");
  let subscriptions = 0, registrations = 0, closures = 0, disposedPorts = 0, markerReads = 0, cancelled2 = false, stopping = false, closing;
  let firstController, observer;
  const scope2 = Object.freeze({
    directory: project,
    workspaceID: ctx.location.workspaceID,
    project: Object.freeze({ id: ctx.location.project.id })
  }), view = createNativeV2(ctx, scope2, () => {
  }, () => fail());
  const sameScope = () => scopeOK(ctx.location?.directory) && ctx.location.project.id === scope2.project.id && ctx.location.workspaceID === scope2.workspaceID;
  const context = { app: ctx.app, event: { subscribe({ signal }) {
    if (++subscriptions > 2) {
      fail("unexpected_reader_replacement");
      throw Error("reader limit");
    }
    const number = subscriptions, ctrl = new AbortController();
    if (number === 1) firstController = ctrl;
    const abort = () => ctrl.abort();
    signal.addEventListener("abort", abort, { once: true });
    if (signal.aborted) abort();
    const stream = ctx.event.subscribe({ signal: ctrl.signal }), iterator = stream[Symbol.asyncIterator]();
    let closed = false, returned;
    function closeObserved(cause) {
      if (closed) return;
      closed = true;
      closures++;
      signal.removeEventListener("abort", abort);
      view.reset();
      record("native-reader-close", { number, cause, actualSignalAborted: ctrl.signal.aborted });
    }
    function actualClose(cause) {
      returned ??= (async () => {
        try {
          const result = await iterator.return();
          if (result?.done !== true) throw Error("native return did not finish");
          closeObserved(cause);
          return result;
        } catch (error) {
          fail("native_reader_close_failed");
          throw error;
        }
      })();
      return returned;
    }
    record("native-reader-open", { number });
    return { [Symbol.asyncIterator]() {
      return this;
    }, async next() {
      try {
        const result = await iterator.next();
        if (result.done) await actualClose("actual_done");
        else {
          nativeCalls++;
          record("native-v2", result.value);
        }
        return result;
      } catch (error) {
        await actualClose("actual_error");
        throw error;
      }
    }, async return() {
      return await actualClose("actual_return");
    } };
  } } };
  const realPort = createRPCCheckpoint(ctx, async () => sameScope());
  const checkpoint = { async register(signal, namespace) {
    let port;
    try {
      port = await realPort.register(signal, namespace);
    } catch (error) {
      checkpointException("native_registration", error);
      throw error;
    }
    if (!port) return;
    const number = ++registrations, emitted = /* @__PURE__ */ new Set();
    record("rpc-register", { number });
    return { type: port.type, emit: (nonce) => {
      try {
        emitted.add(nonce);
      } catch (error) {
        checkpointException("consumer_nonce_tracking", error);
        throw error;
      }
      record("checkpoint-stage", { stage: "native_emit_started" });
      let pending;
      try {
        pending = port.emit(nonce);
      } catch (error) {
        checkpointException("native_emit", error);
        throw error;
      }
      return Promise.resolve(pending).then(
        (value) => {
          record("checkpoint-stage", { stage: "native_emit_returned" });
          return value;
        },
        (error) => {
          checkpointException("native_emit", error);
          throw error;
        }
      );
    }, read(envelope) {
      const nonce = port.read(envelope);
      if (nonce === void 0) return nonce;
      if (!emitted.delete(nonce)) {
        fail("unexpected_checkpoint_nonce");
        return void 0;
      }
      markerReads++;
      record("rpc-marker-consumed", { number, markerReads });
      if (number === 1 && !cancelled2) {
        cancelled2 = true;
        queueMicrotask(() => {
          record("requested-native-abort", { number });
          firstController.abort();
        });
      } else if (number === 2 && markerReads === 2) {
        publish("reader-ready.json", receipt("v2", {
          realMarkerConsumed: true,
          subscriptions,
          registrations,
          firstReaderClosureObserved: closures === 1,
          actualAbortRequested: cancelled2
        }));
        if (own.apiOnlyReadiness === true) queueMicrotask(() => void stop().catch(() => fail("consumer_dispose_failed")));
      }
      return nonce;
    }, async dispose() {
      await port.dispose();
      disposedPorts++;
      record("rpc-disposed", { number });
    } };
  } };
  async function stop(native = false) {
    if (closing) return closing;
    const deadline = performance.now() + 2e3;
    stopping = true;
    observer.dispose();
    closing = (async () => {
      await boundedDrain(observer.done(), deadline);
      if (performance.now() > deadline || subscriptions !== 2 || closures !== 2 || disposedPorts !== 2) throw Error("V2 actual closure");
      publish("reader-closed.json", receipt("v2", {
        actualSDKDispose: true,
        actualSDKDone: true,
        subscriptions,
        actualNativeReaderClosures: closures,
        registrations,
        actualRegistrationDisposals: disposedPorts,
        markerReads,
        actualAbortRequested: cancelled2,
        nativeCleanupHookObserved: native,
        sdkFacts,
        nativeCalls,
        closureCause: own.apiOnlyReadiness === true ? "consumer_after_actual_readiness_markers" : "consumer_after_real_sdk_fact"
      }));
      record("reader-closed", { actualDrain: true });
      closeSync(fd);
      fdOpen = false;
    })();
    return closing;
  }
  observer = createV2Observer({
    context,
    location: project,
    native: view.native,
    checkpoint,
    runtimeEligibility: (version) => version === own.version && sameScope() ? "supported" : "unverified",
    onDiagnostic: diagnostic,
    beforeEmit: (event, handoff) => sameScope() && view.finalize(event, handoff),
    emit(event, handoff) {
      const projected = view.project(event);
      if (stopping || !sameScope() || !handoff.isCurrent() || handoff.signal.aborted || !projected || event.kind !== "turn_idle_verified" || event.rootSession !== true || ++sdkFacts !== 1) {
        fail("SDK fact rejected");
        return;
      }
      record("sdk-fact", {
        event,
        projected,
        clockID: handoff.clockID,
        ingressMonotonicMs: handoff.ingressMonotonicMs,
        currentAtCallback: handoff.isCurrent(),
        nativeCallbackCount: nativeCalls
      });
      queueMicrotask(() => void stop().catch(() => fail("consumer_dispose_failed")));
    }
  });
  const cleanup = () => stop(true);
  slots.set(ctx, cleanup);
  record("loader", { branch: "v2", scopeVerified: true });
  observer.start();
  return cleanup;
}
var consumer_default = { id: "an-test-portable-public-packaged-reader", server, setup };
export {
  consumer_default as default
};
